import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as RotateCcw, r as RotateCw, t as Undo2 } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C_rgV1Ya.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BALL_R = .04;
var FRICTION = 1.05;
var POCKETS = [
	{
		id: "tl",
		name: "Top left",
		x: 0,
		y: 0,
		lip: .062
	},
	{
		id: "tr",
		name: "Top right",
		x: 2,
		y: 0,
		lip: .062
	},
	{
		id: "bl",
		name: "Bottom left",
		x: 0,
		y: 1,
		lip: .062
	},
	{
		id: "br",
		name: "Bottom right",
		x: 2,
		y: 1,
		lip: .062
	},
	{
		id: "t",
		name: "Top side",
		x: 1,
		y: 0,
		lip: .05
	},
	{
		id: "b",
		name: "Bottom side",
		x: 1,
		y: 1,
		lip: .05
	}
];
var MOUTH = .145;
var SIDE_MOUTH = .12;
function pocketById(id) {
	const pocket = POCKETS.find((p) => p.id === id);
	if (!pocket) throw new Error(`Unknown pocket ${id}`);
	return pocket;
}
function ballName(n) {
	if (n === 0) return "Cue ball";
	if (n === 8) return "8-ball";
	return `${n}-ball`;
}
function makeBall(n, x, y) {
	return {
		id: n === 0 ? "cue" : `b${n}`,
		n,
		x,
		y,
		pocketed: false
	};
}
function launchSpeed(power) {
	return .55 + Math.min(1, Math.max(0, power)) * 2.85;
}
function shotRange(power) {
	const v = launchSpeed(power);
	return v * v / (2 * FRICTION);
}
function sub(a, b) {
	return {
		x: a.x - b.x,
		y: a.y - b.y
	};
}
function add(a, b) {
	return {
		x: a.x + b.x,
		y: a.y + b.y
	};
}
function mul(a, s) {
	return {
		x: a.x * s,
		y: a.y * s
	};
}
function len(a) {
	return Math.hypot(a.x, a.y);
}
function norm(a) {
	const l = len(a);
	if (l < 1e-8) return {
		x: 1,
		y: 0
	};
	return {
		x: a.x / l,
		y: a.y / l
	};
}
function clamp(v, lo, hi) {
	return Math.min(hi, Math.max(lo, v));
}
function ghostForPot(ball, pocket) {
	return sub(ball, mul(norm(sub(pocket, ball)), BALL_R * 2));
}
function ghostPlayable(g) {
	return g.x >= .04 * .7 && g.x <= 2 - .04 * .7 && g.y >= .04 * .7 && g.y <= 1 - .04 * .7;
}
function cutAngle(cue, ghost, object) {
	const a = sub(ghost, cue);
	const b = sub(object, ghost);
	const am = len(a);
	const bm = len(b);
	if (am < 1e-6 || bm < 1e-6) return 0;
	const cos = clamp((a.x * b.x + a.y * b.y) / (am * bm), -1, 1);
	return Math.acos(cos);
}
function aimError(cue, ghost, aim) {
	let d = Math.atan2(ghost.y - cue.y, ghost.x - cue.x) - aim;
	while (d > Math.PI) d -= Math.PI * 2;
	while (d < -Math.PI) d += Math.PI * 2;
	return d;
}
function segmentBlocked(a, b, balls, ignore) {
	const dx = b.x - a.x;
	const dy = b.y - a.y;
	const len2 = dx * dx + dy * dy;
	if (len2 < 1e-8) return false;
	const limit = BALL_R * 2 - .004;
	for (const ball of balls) {
		if (ball.pocketed || ignore.has(ball.id)) continue;
		const t = ((ball.x - a.x) * dx + (ball.y - a.y) * dy) / len2;
		if (t <= .04 || t >= .96) continue;
		const px = a.x + dx * t;
		const py = a.y + dy * t;
		if (Math.hypot(ball.x - px, ball.y - py) < limit) return true;
	}
	return false;
}
function bestPocket(balls, ball) {
	const cue = balls.find((b) => b.n === 0 && !b.pocketed);
	let best = null;
	for (const pocket of POCKETS) {
		const ghost = ghostForPot(ball, pocket);
		if (!ghostPlayable(ghost)) continue;
		if (segmentBlocked(ball, pocket, balls, /* @__PURE__ */ new Set([ball.id]))) continue;
		if (cue && segmentBlocked(cue, ghost, balls, /* @__PURE__ */ new Set([ball.id, cue.id]))) continue;
		const cut = cue ? cutAngle(cue, ghost, ball) : 0;
		if (cut > 1.22) continue;
		const score = cut + (cue ? len(sub(ghost, cue)) : 0) * .12;
		if (!best || score < best.score) best = {
			id: pocket.id,
			score
		};
	}
	return best?.id ?? null;
}
function clampBall(pos, balls, id) {
	let x = clamp(pos.x, BALL_R, 1.96);
	let y = clamp(pos.y, BALL_R, .96);
	for (let pass = 0; pass < 3; pass++) {
		for (const other of balls) {
			if (other.id === id || other.pocketed) continue;
			const dx = x - other.x;
			const dy = y - other.y;
			const d = Math.hypot(dx, dy);
			const min = .0815;
			if (d < min) {
				const nx = d < 1e-6 ? 1 : dx / d;
				const ny = d < 1e-6 ? 0 : dy / d;
				x = other.x + nx * min;
				y = other.y + ny * min;
			}
		}
		x = clamp(x, BALL_R, 1.96);
		y = clamp(y, BALL_R, .96);
	}
	return {
		x,
		y
	};
}
function inMouth(x, y) {
	const nearEnd = x < MOUTH || x > 1.855;
	const nearSide = y < MOUTH || y > .855;
	if (nearEnd && nearSide) return true;
	if (Math.abs(x - 1) < SIDE_MOUTH && nearSide) return true;
	return false;
}
function nearestPocket(x, y) {
	let best = null;
	let bestD = .16;
	for (const pocket of POCKETS) {
		const d = Math.hypot(x - pocket.x, y - pocket.y);
		if (d < bestD) {
			best = pocket;
			bestD = d;
		}
	}
	return best;
}
function simulate(balls, aim, power, spin) {
	const ordered = balls.map((b) => ({ ...b }));
	const live = ordered.map((b) => ({
		...b,
		vx: 0,
		vy: 0
	}));
	new Map(live.map((b, i) => [b.id, i]));
	const cue = live.find((b) => b.n === 0 && !b.pocketed);
	const frames = [];
	const samples = /* @__PURE__ */ new Map();
	for (const ball of live) samples.set(ball.id, [{
		x: ball.x,
		y: ball.y
	}]);
	const pocketed = [];
	const bounces = {};
	let firstContact = null;
	let spinUsed = false;
	const snap = () => {
		frames.push({
			xs: live.map((b) => b.x),
			ys: live.map((b) => b.y),
			down: live.map((b) => b.pocketed)
		});
	};
	snap();
	if (!cue || power < .03) return {
		frames,
		tracks: [],
		pocketed,
		firstContact,
		endBalls: ordered,
		bounces
	};
	const speed = launchSpeed(power);
	cue.vx = Math.cos(aim) * speed;
	cue.vy = Math.sin(aim) * speed;
	const dt = 1 / 120;
	let idle = 0;
	for (let step = 0; step < 840; step++) {
		let moving = false;
		const prev = live.map((b) => ({
			x: b.x,
			y: b.y
		}));
		for (const ball of live) {
			if (ball.pocketed) continue;
			const sp = Math.hypot(ball.vx, ball.vy);
			if (sp < .025) {
				ball.vx = 0;
				ball.vy = 0;
				continue;
			}
			moving = true;
			const next = Math.max(0, sp - FRICTION * dt);
			const k = sp > 0 ? next / sp : 0;
			ball.vx *= k;
			ball.vy *= k;
			ball.x += ball.vx * dt;
			ball.y += ball.vy * dt;
		}
		for (let iter = 0; iter < 4; iter++) for (let i = 0; i < live.length; i++) for (let j = i + 1; j < live.length; j++) {
			const a = live[i];
			const b = live[j];
			if (a.pocketed || b.pocketed) continue;
			let dx = b.x - a.x;
			let dy = b.y - a.y;
			let dist = Math.hypot(dx, dy);
			const min = BALL_R * 2;
			if (dist < 1e-8) {
				dx = min;
				dy = 0;
				dist = min;
			}
			if (dist >= min) continue;
			const nx = dx / dist;
			const ny = dy / dist;
			const overlap = min - dist;
			a.x -= nx * overlap * .5;
			a.y -= ny * overlap * .5;
			b.x += nx * overlap * .5;
			b.y += ny * overlap * .5;
			const rel = (a.vx - b.vx) * nx + (a.vy - b.vy) * ny;
			if (rel <= 1e-4) continue;
			a.vx -= nx * rel;
			a.vy -= ny * rel;
			b.vx += nx * rel;
			b.vy += ny * rel;
			const cueBall = a.n === 0 ? a : b.n === 0 ? b : null;
			const other = cueBall === a ? b : cueBall === b ? a : null;
			if (cueBall && other && !spinUsed && iter === 0) {
				spinUsed = true;
				const cnx = other.x - cueBall.x;
				const cny = other.y - cueBall.y;
				const cl = Math.hypot(cnx, cny) || 1;
				const nxC = cnx / cl;
				const nyC = cny / cl;
				const follow = clamp(spin.y, -1, 1);
				const english = clamp(spin.x, -1, 1);
				cueBall.vx += nxC * rel * follow * .82;
				cueBall.vy += nyC * rel * follow * .82;
				cueBall.vx += -nyC * english * rel * .28;
				cueBall.vy += nxC * english * rel * .28;
				const throwAng = -english * .07;
				const ox = other.vx;
				const oy = other.vy;
				const c = Math.cos(throwAng);
				const s = Math.sin(throwAng);
				other.vx = ox * c - oy * s;
				other.vy = ox * s + oy * c;
				firstContact = {
					id: other.id,
					ghost: {
						x: cueBall.x,
						y: cueBall.y
					}
				};
			}
		}
		for (let i = 0; i < live.length; i++) {
			const ball = live[i];
			if (ball.pocketed) continue;
			const before = prev[i];
			const sp = Math.hypot(ball.vx, ball.vy);
			if (sp > .05) {
				const hole = enteredPocket(before, ball);
				if (hole) {
					ball.pocketed = true;
					ball.vx = 0;
					ball.vy = 0;
					ball.x = hole.x;
					ball.y = hole.y;
					pocketed.push({
						id: ball.id,
						pocket: hole.id
					});
					continue;
				}
			}
			if (inMouth(ball.x, ball.y)) {
				const hole = nearestPocket(ball.x, ball.y);
				if (hole && Math.hypot(ball.x - hole.x, ball.y - hole.y) < .1 && sp > .08) {
					const pull = 2.4 * dt;
					ball.vx += (hole.x - ball.x) * pull;
					ball.vy += (hole.y - ball.y) * pull;
				}
				continue;
			}
			const damp = .74;
			let hit = false;
			if (ball.x < .04) {
				ball.x = BALL_R;
				ball.vx = Math.abs(ball.vx) * damp;
				hit = true;
			} else if (ball.x > 1.96) {
				ball.x = 1.96;
				ball.vx = -Math.abs(ball.vx) * damp;
				hit = true;
			}
			if (ball.y < .04) {
				ball.y = BALL_R;
				ball.vy = Math.abs(ball.vy) * damp;
				hit = true;
			} else if (ball.y > .96) {
				ball.y = .96;
				ball.vy = -Math.abs(ball.vy) * damp;
				hit = true;
			}
			if (hit) bounces[ball.id] = (bounces[ball.id] ?? 0) + 1;
		}
		if (step % 2 === 0) {
			snap();
			for (const ball of live) {
				if (ball.pocketed) continue;
				const pts = samples.get(ball.id);
				if (!pts) continue;
				const last = pts[pts.length - 1];
				if (Math.hypot(ball.x - last.x, ball.y - last.y) > .01) pts.push({
					x: ball.x,
					y: ball.y
				});
			}
		}
		if (!moving) {
			idle++;
			if (idle > 8) break;
		} else idle = 0;
	}
	snap();
	const tracks = [];
	for (const [id, pts] of samples) {
		if (pts.length < 2) continue;
		let travel = 0;
		for (let i = 1; i < pts.length; i++) travel += Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
		if (travel < .03) continue;
		tracks.push({
			id,
			pts
		});
	}
	const endBalls = live.map((b) => ({
		id: b.id,
		n: b.n,
		x: clamp(b.x, BALL_R, 1.96),
		y: clamp(b.y, BALL_R, .96),
		pocketed: b.pocketed
	}));
	return {
		frames,
		tracks,
		pocketed,
		firstContact,
		endBalls,
		bounces
	};
}
function enteredPocket(prev, ball) {
	for (const pocket of POCKETS) {
		const d1 = Math.hypot(ball.x - pocket.x, ball.y - pocket.y);
		if (d1 > pocket.lip) continue;
		if (!(ball.x < .04 * .45 || ball.x > 2 - .04 * .45 || ball.y < .04 * .45 || ball.y > 1 - .04 * .45) && d1 > pocket.lip * .5) continue;
		const d0 = Math.hypot(prev.x - pocket.x, prev.y - pocket.y);
		if (d1 <= d0 || d0 > pocket.lip) return pocket;
	}
	return null;
}
function analyze(balls, aim, power, spin, calledBallId, calledPocketId) {
	const sim = simulate(balls, aim, power, spin);
	const cue = balls.find((b) => b.n === 0 && !b.pocketed);
	const called = balls.find((b) => b.id === calledBallId && !b.pocketed);
	const pocket = calledPocketId ? pocketById(calledPocketId) : null;
	let call = null;
	if (cue && called && pocket) {
		const ghost = ghostForPot(called, pocket);
		call = {
			ghost,
			cut: cutAngle(cue, ghost, called),
			error: aimError(cue, ghost, aim),
			blockedBall: segmentBlocked(called, pocket, balls, /* @__PURE__ */ new Set([called.id])),
			blockedCue: segmentBlocked(cue, ghost, balls, /* @__PURE__ */ new Set([called.id, cue.id])),
			playable: ghostPlayable(ghost),
			reach: len(sub(ghost, cue)),
			range: shotRange(power)
		};
	}
	const cueDown = sim.pocketed.some((p) => p.id === "cue");
	const calledHit = called ? sim.pocketed.find((p) => p.id === called.id) : void 0;
	const cutDeg = call ? call.cut * 180 / Math.PI : null;
	const offDeg = call ? Math.abs(call.error * 180 / Math.PI) : null;
	let status = "miss";
	let title = "No contact";
	let detail = "The cue ball never finds a ball.";
	if (!balls.some((b) => b.n !== 0 && !b.pocketed)) {
		status = "clear";
		title = "Table clear";
		detail = "Re-rack when you want another leave.";
	} else if (!cue) {
		status = "hand";
		title = "Cue in hand";
		detail = "Tap the cloth to place the cue ball.";
	} else if (cueDown && calledHit) {
		status = "scratch";
		title = "Scratch";
		detail = "The called ball drops, and so does the cue.";
	} else if (cueDown) {
		status = "scratch";
		title = "Scratch";
		detail = "The cue ball finds a pocket on this line.";
	} else if (called && calledHit && pocket && calledHit.pocket === pocket.id) {
		const banked = (sim.bounces[called.id] ?? 0) > 0;
		if (sim.firstContact != null && sim.firstContact.id !== called.id) {
			status = "combo";
			title = "Combo";
			detail = "The first ball sends the called ball in.";
		} else if (banked) {
			status = "bank";
			title = "Bank";
			detail = "Off the cushion and into the called pocket.";
		} else if (offDeg != null && offDeg < 1.4) {
			status = "line";
			title = "On the line";
			detail = "Ghost ball and cue track agree.";
		} else {
			status = "make";
			title = "Make";
			detail = "This stroke pots the called ball.";
		}
	} else if (called && calledHit && pocket) {
		status = "wrong";
		title = "Wrong pocket";
		detail = `It falls in the ${pocketById(calledHit.pocket).name.toLowerCase()} pocket.`;
	} else if (called && calledHit) {
		status = "make";
		title = "Pocket";
		detail = `The ${ballName(called.n)} finds the ${pocketById(calledHit.pocket).name.toLowerCase()}.`;
	} else if (call && (call.blockedBall || call.blockedCue)) {
		status = "blocked";
		title = "Blocked";
		detail = call.blockedBall ? "Another ball sits on the way to the pocket." : "The path to the ghost ball is not clear.";
	} else if (call && !call.playable) {
		status = "blocked";
		title = "No ghost";
		detail = "That pocket needs the cue ball off the table.";
	} else if (call && call.cut > 1.2) {
		status = "thin";
		title = "Too thin";
		detail = "The cut is past what a center-ball hit can hold.";
	} else if (call && call.reach > call.range * .96) {
		status = "short";
		title = "Short";
		detail = "Add power if you want the cue to reach.";
	} else if (call && offDeg != null && offDeg >= 1.4) {
		status = "off";
		title = "Off the ghost";
		detail = `${offDeg.toFixed(1)}° away from the pot line.`;
	} else if (sim.firstContact) {
		const calledShot = Boolean(called && pocket);
		status = "miss";
		title = calledShot ? "Miss" : "Track";
		detail = calledShot ? "Contact, then the object ball drifts wide." : "White follows the cue. Gold follows the first ball it meets.";
	}
	return {
		sim,
		call,
		status,
		title,
		detail,
		cutDeg
	};
}
function aimToward(from, to) {
	return Math.atan2(to.y - from.y, to.x - from.x);
}
function safeCue(pos, others) {
	const placed = clampBall(pos, others, "cue");
	return makeBall(0, placed.x, placed.y);
}
function cornerPreset() {
	const pocket = pocketById("tr");
	const ball = makeBall(3, 1.28, .34);
	const ghost = ghostForPot(ball, pocket);
	const dir = norm(sub(ball, ghost));
	const eight = makeBall(8, 1.58, .74);
	const nine = makeBall(11, .86, .24);
	const cue = safeCue(sub(ghost, mul(dir, .58)), [
		ball,
		eight,
		nine
	]);
	return {
		id: "corner",
		name: "Corner",
		hint: "A called corner. Match the gold ghost.",
		balls: [
			cue,
			ball,
			eight,
			nine
		],
		aim: aimToward(cue, ghost),
		power: .62,
		spin: {
			x: 0,
			y: 0
		},
		calledBallId: ball.id,
		calledPocketId: "tr"
	};
}
function sidePreset() {
	const pocket = pocketById("t");
	const ball = makeBall(5, 1.12, .46);
	const ghost = ghostForPot(ball, pocket);
	const dir = norm(sub(ball, ghost));
	const eight = makeBall(8, 1.66, .8);
	const ten = makeBall(10, .48, .22);
	const cue = safeCue(sub(ghost, mul(dir, .3)), [
		ball,
		eight,
		ten
	]);
	return {
		id: "side",
		name: "Side",
		hint: "Straight into the side pocket.",
		balls: [
			cue,
			ball,
			eight,
			ten
		],
		aim: aimToward(cue, ghost),
		power: .6,
		spin: {
			x: 0,
			y: 0
		},
		calledBallId: ball.id,
		calledPocketId: "t"
	};
}
function thinPreset() {
	const cue = makeBall(0, .42, .3);
	const ball = makeBall(1, 1.3, .55);
	return {
		id: "thin",
		name: "Thin cut",
		hint: "The line is on the ball. Slide it onto the ghost.",
		balls: [
			cue,
			ball,
			makeBall(8, .72, .8),
			makeBall(9, 1.72, .2)
		],
		aim: aimToward(cue, ball),
		power: .7,
		spin: {
			x: 0,
			y: 0
		},
		calledBallId: ball.id,
		calledPocketId: "br"
	};
}
function comboPreset() {
	const pocket = pocketById("br");
	const target = makeBall(6, 1.42, .62);
	const dir = norm(sub(pocket, target));
	const first = makeBall(2, target.x - dir.x * .092, target.y - dir.y * .092);
	const cue = safeCue(sub(ghostForPot(first, add(first, dir)), mul(dir, .48)), [
		target,
		first,
		makeBall(8, .55, .28)
	]);
	return {
		id: "combo",
		name: "Combo",
		hint: "Cue hits the 2, the 2 hits the 6.",
		balls: [
			cue,
			first,
			target,
			makeBall(8, .55, .28)
		],
		aim: aimToward(cue, ghostForPot(first, target)),
		power: .78,
		spin: {
			x: 0,
			y: 0
		},
		calledBallId: target.id,
		calledPocketId: "br"
	};
}
function bankPreset() {
	const ball = makeBall(4, .8, .5);
	const cue = makeBall(0, 1.06, .15);
	const eight = makeBall(8, 1.64, .78);
	const ghost = sub(ball, mul(norm(sub({
		x: 0,
		y: 2
	}, ball)), BALL_R * 2));
	return {
		id: "bank",
		name: "Bank",
		hint: "One rail off the bottom into the top left.",
		balls: [
			cue,
			ball,
			eight
		],
		aim: aimToward(cue, ghost),
		power: .88,
		spin: {
			x: 0,
			y: 0
		},
		calledBallId: ball.id,
		calledPocketId: "tl"
	};
}
function eightPreset() {
	const pocket = pocketById("br");
	const ball = makeBall(8, 1.36, .62);
	const ghost = ghostForPot(ball, pocket);
	const cue = safeCue(sub(ghost, mul(norm(sub(ball, ghost)), .64)), [ball]);
	return {
		id: "eight",
		name: "8-ball",
		hint: "Game ball. Keep the cue out of the pocket.",
		balls: [cue, ball],
		aim: aimToward(cue, ghost),
		power: .6,
		spin: {
			x: 0,
			y: 0
		},
		calledBallId: ball.id,
		calledPocketId: "br"
	};
}
function rackPreset() {
	const gap = BALL_R * 2.05;
	const apex = {
		x: 1.52,
		y: .5
	};
	const numbers = [
		[1],
		[9, 2],
		[
			10,
			8,
			3
		],
		[
			11,
			4,
			12,
			5
		],
		[
			6,
			13,
			7,
			14,
			15
		]
	];
	const balls = [];
	for (let row = 0; row < numbers.length; row++) for (let col = 0; col < numbers[row].length; col++) {
		const n = numbers[row][col];
		const x = apex.x + row * gap * Math.cos(Math.PI / 6);
		const y = apex.y + (col - row / 2) * gap;
		balls.push(makeBall(n, x, y));
	}
	const cue = makeBall(0, .48, .5);
	balls.unshift(cue);
	const one = balls.find((b) => b.n === 1);
	const pocket = bestPocket(balls, one);
	return {
		id: "rack",
		name: "Full rack",
		hint: "Open the 1, or drag any ball out and call it.",
		balls,
		aim: aimToward(cue, pocket ? ghostForPot(one, pocketById(pocket)) : one),
		power: .92,
		spin: {
			x: 0,
			y: 0
		},
		calledBallId: one.id,
		calledPocketId: pocket
	};
}
var PRESETS = [
	cornerPreset(),
	sidePreset(),
	thinPreset(),
	comboPreset(),
	bankPreset(),
	eightPreset(),
	rackPreset()
];
function presetById(id) {
	return PRESETS.find((p) => p.id === id) ?? PRESETS[0];
}
var BALL_COLORS = {
	1: "#f0d23c",
	2: "#3a78d8",
	3: "#e23d3d",
	4: "#7a4fd0",
	5: "#ef8a2a",
	6: "#1f8f52",
	7: "#8d3140",
	8: "#141414",
	9: "#f0d23c",
	10: "#3a78d8",
	11: "#e23d3d",
	12: "#7a4fd0",
	13: "#ef8a2a",
	14: "#1f8f52",
	15: "#8d3140"
};
var CREAM = "#f3efe4";
var GOLD = "#e4b15a";
var noiseCanvas = null;
function feltNoise() {
	if (noiseCanvas) return noiseCanvas;
	const canvas = document.createElement("canvas");
	canvas.width = 180;
	canvas.height = 180;
	const ctx = canvas.getContext("2d");
	if (!ctx) return canvas;
	for (let i = 0; i < 900; i++) {
		ctx.fillStyle = Math.random() > .5 ? "rgba(255,255,255,0.045)" : "rgba(0,0,0,0.05)";
		ctx.fillRect(Math.random() * 180, Math.random() * 180, 1.2, 1.2);
	}
	noiseCanvas = canvas;
	return canvas;
}
function layoutFor(width, height) {
	const portrait = height > width * .92 && width < 900;
	const rail = Math.max(14, Math.min(width, height) * .034);
	const aspect = portrait ? 1 / 2 : 2;
	const maxW = Math.max(40, width - 16 - rail * 2);
	const maxH = Math.max(40, height - 16 - rail * 2);
	let feltW;
	let feltH;
	if (maxW / maxH > aspect) {
		feltH = maxH;
		feltW = feltH * aspect;
	} else {
		feltW = maxW;
		feltH = feltW / aspect;
	}
	const scale = portrait ? feltW / 1 : feltW / 2;
	const outerW = feltW + rail * 2;
	const outerH = feltH + rail * 2;
	const ox = (width - outerW) / 2;
	const oy = (height - outerH) / 2;
	return {
		portrait,
		scale,
		rail,
		ox,
		oy,
		fx: ox + rail,
		fy: oy + rail,
		feltW,
		feltH
	};
}
function toScreen(x, y, layout) {
	if (!layout.portrait) return {
		x: layout.fx + x * layout.scale,
		y: layout.fy + y * layout.scale
	};
	return {
		x: layout.fx + y * layout.scale,
		y: layout.fy + x * layout.scale
	};
}
function toTable(sx, sy, layout) {
	if (!layout.portrait) return {
		x: (sx - layout.fx) / layout.scale,
		y: (sy - layout.fy) / layout.scale
	};
	return {
		x: (sy - layout.fy) / layout.scale,
		y: (sx - layout.fx) / layout.scale
	};
}
function aimOnScreen(aim, portrait) {
	const tx = Math.cos(aim);
	const ty = Math.sin(aim);
	return portrait ? {
		x: ty,
		y: tx
	} : {
		x: tx,
		y: ty
	};
}
function roundRect(ctx, x, y, w, h, r) {
	const radius = Math.min(r, w / 2, h / 2);
	ctx.beginPath();
	ctx.moveTo(x + radius, y);
	ctx.arcTo(x + w, y, x + w, y + h, radius);
	ctx.arcTo(x + w, y + h, x, y + h, radius);
	ctx.arcTo(x, y + h, x, y, radius);
	ctx.arcTo(x, y, x + w, y, radius);
	ctx.closePath();
}
function shade(hex, amt) {
	const n = Number.parseInt(hex.slice(1), 16);
	return `rgb(${Math.min(255, Math.max(0, (n >> 16 & 255) + amt))} ${Math.min(255, Math.max(0, (n >> 8 & 255) + amt))} ${Math.min(255, Math.max(0, (n & 255) + amt))})`;
}
function drawDots(ctx, pts, color, radius) {
	if (pts.length < 2) return;
	const spacing = 12;
	let carry = 0;
	ctx.fillStyle = color;
	for (let i = 1; i < pts.length; i++) {
		const a = pts[i - 1];
		const b = pts[i];
		const dx = b.x - a.x;
		const dy = b.y - a.y;
		const dist = Math.hypot(dx, dy);
		if (dist < .001) continue;
		let traveled = carry;
		while (traveled < dist) {
			const t = traveled / dist;
			ctx.beginPath();
			ctx.arc(a.x + dx * t, a.y + dy * t, radius, 0, Math.PI * 2);
			ctx.fill();
			traveled += spacing;
		}
		carry = traveled - dist;
	}
}
function drawBall(ctx, x, y, r, ball) {
	ctx.beginPath();
	ctx.arc(x + r * .12, y + r * .2, r, 0, Math.PI * 2);
	ctx.fillStyle = "rgba(0,0,0,0.28)";
	ctx.fill();
	ctx.beginPath();
	ctx.arc(x, y, r, 0, Math.PI * 2);
	const stripe = ball.n > 8;
	const color = BALL_COLORS[ball.n] ?? CREAM;
	if (ball.n === 0) {
		const g = ctx.createRadialGradient(x - r * .35, y - r * .4, r * .1, x, y, r);
		g.addColorStop(0, "#ffffff");
		g.addColorStop(.72, "#f3efe4");
		g.addColorStop(1, "#cfc6b6");
		ctx.fillStyle = g;
		ctx.fill();
	} else if (stripe) {
		ctx.save();
		ctx.clip();
		ctx.fillStyle = "#f7f4ee";
		ctx.fillRect(x - r, y - r, r * 2, r * 2);
		ctx.fillStyle = color;
		ctx.fillRect(x - r, y - r * .46, r * 2, r * .92);
		ctx.restore();
		ctx.beginPath();
		ctx.arc(x, y, r, 0, Math.PI * 2);
		ctx.strokeStyle = "rgba(0,0,0,0.25)";
		ctx.lineWidth = 1;
		ctx.stroke();
	} else {
		const g = ctx.createRadialGradient(x - r * .32, y - r * .38, r * .1, x, y, r);
		g.addColorStop(0, ball.n === 8 ? "#4a4a4a" : shade(color, 70));
		g.addColorStop(.55, color);
		g.addColorStop(1, shade(color, -40));
		ctx.fillStyle = g;
		ctx.fill();
	}
	if (ball.n !== 0 && r > 7) {
		ctx.beginPath();
		ctx.arc(x, y, r * .46, 0, Math.PI * 2);
		ctx.fillStyle = "#f7f4ee";
		ctx.fill();
		ctx.fillStyle = "#1a140c";
		ctx.font = `700 ${Math.max(8, r * .72)}px "Barlow Condensed", sans-serif`;
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.fillText(String(ball.n), x, y + r * .04);
	}
	ctx.beginPath();
	ctx.ellipse(x - r * .28, y - r * .34, r * .26, r * .14, -.7, 0, Math.PI * 2);
	ctx.fillStyle = "rgba(255,255,255,0.45)";
	ctx.fill();
}
function PoolCanvas({ balls, aim, power, calledBallId, calledPocketId, showCall, showTracks, analysis, playback, placing, onPlaybackDone, onAim, onMoveBall, onSelectBall, onSelectPocket, onPlaceCue }) {
	const wrapRef = (0, import_react.useRef)(null);
	const canvasRef = (0, import_react.useRef)(null);
	const propsRef = (0, import_react.useRef)({
		balls,
		aim,
		power,
		calledBallId,
		calledPocketId,
		showCall,
		showTracks,
		analysis,
		playback,
		placing,
		onPlaybackDone,
		onAim,
		onMoveBall,
		onSelectBall,
		onSelectPocket,
		onPlaceCue
	});
	propsRef.current = {
		balls,
		aim,
		power,
		calledBallId,
		calledPocketId,
		showCall,
		showTracks,
		analysis,
		playback,
		placing,
		onPlaybackDone,
		onAim,
		onMoveBall,
		onSelectBall,
		onSelectPocket,
		onPlaceCue
	};
	const dragRef = (0, import_react.useRef)(null);
	const playRef = (0, import_react.useRef)({
		sim: null,
		started: 0,
		done: false
	});
	(0, import_react.useEffect)(() => {
		const wrap = wrapRef.current;
		const canvas = canvasRef.current;
		if (!wrap || !canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		let frame = 0;
		const draw = (now) => {
			const rect = wrap.getBoundingClientRect();
			const dpr = Math.min(2, window.devicePixelRatio || 1);
			const w = Math.max(1, rect.width);
			const h = Math.max(1, rect.height);
			const pw = Math.floor(w * dpr);
			const ph = Math.floor(h * dpr);
			if (canvas.width !== pw || canvas.height !== ph) {
				canvas.width = pw;
				canvas.height = ph;
			}
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
			ctx.clearRect(0, 0, w, h);
			const layout = layoutFor(w, h);
			const props = propsRef.current;
			const playing = props.playback;
			if (playing && playRef.current.sim !== playing) {
				playRef.current = {
					sim: playing,
					started: now,
					done: false
				};
				if (window.matchMedia("(prefers-reduced-motion: reduce)").matches || playing.frames.length < 2) {
					playRef.current.done = true;
					props.onPlaybackDone(playing.endBalls);
				}
			}
			if (!playing) playRef.current = {
				sim: null,
				started: 0,
				done: false
			};
			let view = props.balls;
			if (playing && playRef.current.sim === playing) {
				const last = playing.frames.length - 1;
				const idx = playRef.current.done ? last : Math.min(last, Math.floor((now - playRef.current.started) / 14));
				const snap = playing.frames[idx];
				if (snap) view = props.balls.map((ball, i) => ({
					...ball,
					x: snap.xs[i] ?? ball.x,
					y: snap.ys[i] ?? ball.y,
					pocketed: snap.down[i] ?? ball.pocketed
				}));
				if (!playRef.current.done && idx >= last) {
					playRef.current.done = true;
					props.onPlaybackDone(playing.endBalls);
				}
			}
			paintTable(ctx, layout);
			const rolling = Boolean(playing && !playRef.current.done);
			if (!rolling) paintGuides(ctx, layout, props);
			for (const ball of view) {
				if (ball.pocketed) continue;
				const p = toScreen(ball.x, ball.y, layout);
				const radius = BALL_R * layout.scale;
				drawBall(ctx, p.x, p.y, radius, ball);
				if (ball.id === props.calledBallId) {
					ctx.beginPath();
					ctx.arc(p.x, p.y, radius + 4, 0, Math.PI * 2);
					ctx.strokeStyle = GOLD;
					ctx.lineWidth = 2;
					ctx.stroke();
				}
			}
			if (!rolling) paintCue(ctx, layout, view, props.aim, props.power);
			frame = requestAnimationFrame(draw);
		};
		frame = requestAnimationFrame(draw);
		return () => cancelAnimationFrame(frame);
	}, []);
	function localPoint(event) {
		const rect = event.currentTarget.getBoundingClientRect();
		return {
			x: event.clientX - rect.left,
			y: event.clientY - rect.top,
			w: rect.width,
			h: rect.height
		};
	}
	function hitBall(px, py, layout, list) {
		const slop = 10;
		for (let i = list.length - 1; i >= 0; i--) {
			const ball = list[i];
			if (ball.pocketed) continue;
			const p = toScreen(ball.x, ball.y, layout);
			if (Math.hypot(p.x - px, p.y - py) <= .04 * layout.scale + slop) return ball;
		}
		return null;
	}
	function hitPocket(px, py, layout) {
		let best = null;
		let bestD = Number.POSITIVE_INFINITY;
		for (const pocket of POCKETS) {
			const p = toScreen(pocket.x, pocket.y, layout);
			const d = Math.hypot(p.x - px, p.y - py);
			if (d < Math.max(24, pocket.lip * layout.scale * 1.8) && d < bestD) {
				best = pocket.id;
				bestD = d;
			}
		}
		return best;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: wrapRef,
		className: "absolute inset-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref: canvasRef,
			className: "h-full w-full touch-none",
			role: "img",
			"aria-label": "8-ball table. Drag the cloth to aim, drag a ball to move it, tap a pocket to call it.",
			onPointerDown: (event) => {
				if (propsRef.current.playback) return;
				const point = localPoint(event);
				const layout = layoutFor(point.w, point.h);
				const table = toTable(point.x, point.y, layout);
				const ball = hitBall(point.x, point.y, layout, propsRef.current.balls);
				const pocket = hitPocket(point.x, point.y, layout);
				event.currentTarget.setPointerCapture(event.pointerId);
				if (propsRef.current.placing && !ball) {
					dragRef.current = {
						kind: "place",
						px: point.x,
						py: point.y
					};
					return;
				}
				if (ball) {
					dragRef.current = {
						kind: "ball",
						id: ball.id,
						moved: false,
						px: point.x,
						py: point.y
					};
					return;
				}
				dragRef.current = {
					kind: "aim",
					moved: false,
					pocket,
					px: point.x,
					py: point.y
				};
				if (!propsRef.current.placing) {
					const cue = propsRef.current.balls.find((b) => b.n === 0 && !b.pocketed);
					if (cue) propsRef.current.onAim(Math.atan2(table.y - cue.y, table.x - cue.x));
				}
			},
			onPointerMove: (event) => {
				const drag = dragRef.current;
				if (!drag || !event.currentTarget.hasPointerCapture(event.pointerId)) return;
				const point = localPoint(event);
				const layout = layoutFor(point.w, point.h);
				const table = toTable(point.x, point.y, layout);
				if (Math.hypot(point.x - drag.px, point.y - drag.py) > 6 && drag.kind !== "place") drag.moved = true;
				if (drag.kind === "ball" && drag.moved) propsRef.current.onMoveBall(drag.id, table.x, table.y);
				else if (drag.kind === "aim" && !propsRef.current.placing) {
					const cue = propsRef.current.balls.find((b) => b.n === 0 && !b.pocketed);
					if (cue) propsRef.current.onAim(Math.atan2(table.y - cue.y, table.x - cue.x));
				}
			},
			onPointerUp: (event) => {
				const playing = propsRef.current.playback;
				if (playing && !playRef.current.done) {
					playRef.current.done = true;
					propsRef.current.onPlaybackDone(playing.endBalls);
					dragRef.current = null;
					return;
				}
				const drag = dragRef.current;
				dragRef.current = null;
				if (!drag) return;
				const point = localPoint(event);
				const layout = layoutFor(point.w, point.h);
				const table = toTable(point.x, point.y, layout);
				if (drag.kind === "place") {
					propsRef.current.onPlaceCue(table.x, table.y);
					return;
				}
				if (drag.kind === "ball" && !drag.moved) {
					const ball = propsRef.current.balls.find((b) => b.id === drag.id);
					if (ball && ball.n !== 0) propsRef.current.onSelectBall(ball.id);
					return;
				}
				if (drag.kind === "aim" && !drag.moved && drag.pocket) propsRef.current.onSelectPocket(drag.pocket);
			}
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "hint-pill pointer-events-none absolute top-3 left-1/2 -translate-x-1/2 rounded-full px-3 py-1 text-center text-sm text-muted",
			children: placing ? "Tap the cloth to drop the cue ball" : "Drag the cloth to aim. Drag a ball to move it."
		})]
	});
}
function paintTable(ctx, layout) {
	const { ox, oy, rail, feltW, feltH, fx, fy } = layout;
	const outerW = feltW + rail * 2;
	const outerH = feltH + rail * 2;
	roundRect(ctx, ox, oy, outerW, outerH, rail * .55);
	const wood = ctx.createLinearGradient(ox, oy, ox + outerW, oy + outerH);
	wood.addColorStop(0, "#8d5a34");
	wood.addColorStop(.45, "#6a3b1e");
	wood.addColorStop(1, "#3e2415");
	ctx.fillStyle = wood;
	ctx.fill();
	ctx.save();
	roundRect(ctx, fx, fy, feltW, feltH, 6);
	ctx.clip();
	const felt = ctx.createRadialGradient(fx + feltW * .5, fy + feltH * .45, feltW * .1, fx + feltW * .5, fy + feltH * .5, feltW * .72);
	felt.addColorStop(0, "#1c8f58");
	felt.addColorStop(.7, "#157a4b");
	felt.addColorStop(1, "#0c4a30");
	ctx.fillStyle = felt;
	ctx.fillRect(fx, fy, feltW, feltH);
	ctx.globalAlpha = .55;
	ctx.drawImage(feltNoise(), fx, fy, feltW, feltH);
	ctx.globalAlpha = 1;
	ctx.restore();
	ctx.save();
	ctx.strokeStyle = "rgba(243,239,228,0.16)";
	ctx.lineWidth = 1;
	ctx.beginPath();
	const headA = toScreen(.5, 0, layout);
	const headB = toScreen(.5, 1, layout);
	ctx.moveTo(headA.x, headA.y);
	ctx.lineTo(headB.x, headB.y);
	ctx.stroke();
	for (const spot of [{
		x: .5,
		y: .5
	}, {
		x: 1.5,
		y: .5
	}]) {
		const p = toScreen(spot.x, spot.y, layout);
		ctx.beginPath();
		ctx.arc(p.x, p.y, 2.5, 0, Math.PI * 2);
		ctx.fillStyle = "rgba(243,239,228,0.35)";
		ctx.fill();
	}
	ctx.restore();
	for (const pocket of POCKETS) {
		const p = toScreen(pocket.x, pocket.y, layout);
		const radius = Math.max(13, pocket.lip * layout.scale * 1.55);
		ctx.beginPath();
		ctx.arc(p.x, p.y, radius, 0, Math.PI * 2);
		const hole = ctx.createRadialGradient(p.x, p.y, radius * .2, p.x, p.y, radius);
		hole.addColorStop(0, "#1a120e");
		hole.addColorStop(1, "#050403");
		ctx.fillStyle = hole;
		ctx.fill();
		ctx.lineWidth = 3;
		ctx.strokeStyle = "#2a1a10";
		ctx.stroke();
	}
	const out = layout.rail / layout.scale * .46;
	const diamonds = [];
	for (const t of [
		.125,
		.25,
		.375,
		.625,
		.75,
		.875
	]) diamonds.push({
		x: 2 * t,
		y: -out
	}, {
		x: 2 * t,
		y: 1 + out
	});
	for (const t of [
		.25,
		.5,
		.75
	]) diamonds.push({
		x: -out,
		y: 1 * t
	}, {
		x: 2 + out,
		y: 1 * t
	});
	ctx.fillStyle = "rgba(228,177,90,0.72)";
	const d = Math.max(3, layout.rail * .16);
	for (const spot of diamonds) {
		const p = toScreen(spot.x, spot.y, layout);
		ctx.beginPath();
		ctx.moveTo(p.x, p.y - d);
		ctx.lineTo(p.x + d * .7, p.y);
		ctx.lineTo(p.x, p.y + d);
		ctx.lineTo(p.x - d * .7, p.y);
		ctx.closePath();
		ctx.fill();
	}
}
function paintGuides(ctx, layout, props) {
	const { analysis } = props;
	const hideIdeal = analysis.status === "bank" || analysis.status === "hand" || analysis.status === "clear";
	if (props.showCall && analysis.call && props.calledPocketId && props.calledBallId && !hideIdeal) {
		const pocket = POCKETS.find((p) => p.id === props.calledPocketId);
		const ball = props.balls.find((b) => b.id === props.calledBallId);
		if (pocket && ball && !ball.pocketed) {
			const p = toScreen(pocket.x, pocket.y, layout);
			const b = toScreen(ball.x, ball.y, layout);
			const g = toScreen(analysis.call.ghost.x, analysis.call.ghost.y, layout);
			const cue = props.balls.find((item) => item.n === 0 && !item.pocketed);
			ctx.save();
			ctx.strokeStyle = "rgba(228,177,90,0.95)";
			ctx.lineWidth = 1.75;
			ctx.setLineDash([6, 7]);
			ctx.beginPath();
			ctx.moveTo(p.x, p.y);
			ctx.lineTo(b.x, b.y);
			ctx.lineTo(g.x, g.y);
			if (cue) {
				const c = toScreen(cue.x, cue.y, layout);
				ctx.moveTo(c.x, c.y);
				ctx.lineTo(g.x, g.y);
			}
			ctx.stroke();
			ctx.beginPath();
			ctx.arc(g.x, g.y, BALL_R * layout.scale, 0, Math.PI * 2);
			ctx.stroke();
			ctx.restore();
		}
	}
	if (props.showTracks) {
		const hit = analysis.sim.firstContact?.id;
		for (const track of analysis.sim.tracks) {
			const pts = track.pts.map((p) => toScreen(p.x, p.y, layout));
			if (track.id === "cue") drawDots(ctx, pts, "rgba(243,239,228,0.92)", 2.15);
			else {
				ctx.beginPath();
				pts.forEach((p, i) => i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y));
				ctx.strokeStyle = track.id === hit ? GOLD : "rgba(243,239,228,0.38)";
				ctx.lineWidth = track.id === hit ? 2.4 : 1.35;
				ctx.lineJoin = "round";
				ctx.lineCap = "round";
				ctx.stroke();
			}
		}
	}
	if (props.calledPocketId) {
		const pocket = POCKETS.find((p) => p.id === props.calledPocketId);
		if (pocket) {
			const p = toScreen(pocket.x, pocket.y, layout);
			ctx.beginPath();
			ctx.arc(p.x, p.y, Math.max(16, pocket.lip * layout.scale * 1.85), 0, Math.PI * 2);
			ctx.strokeStyle = GOLD;
			ctx.lineWidth = 2;
			ctx.stroke();
		}
	}
	const scratch = analysis.sim.pocketed.find((p) => p.id === "cue");
	if (scratch) {
		const pocket = POCKETS.find((p) => p.id === scratch.pocket);
		if (pocket) {
			const p = toScreen(pocket.x, pocket.y, layout);
			ctx.beginPath();
			ctx.setLineDash([3, 4]);
			ctx.arc(p.x, p.y, Math.max(18, pocket.lip * layout.scale * 2.1), 0, Math.PI * 2);
			ctx.strokeStyle = CREAM;
			ctx.lineWidth = 1.5;
			ctx.stroke();
			ctx.setLineDash([]);
		}
	}
}
function paintCue(ctx, layout, balls, aim, power) {
	const cue = balls.find((b) => b.n === 0 && !b.pocketed);
	if (!cue) return;
	const origin = toScreen(cue.x, cue.y, layout);
	const dir = aimOnScreen(aim, layout.portrait);
	const radius = BALL_R * layout.scale;
	const backX = -dir.x;
	const backY = -dir.y;
	const gap = radius * (.85 + power * 1.7);
	const length = Math.min(layout.feltW, layout.feltH) * (layout.portrait ? .42 : .38);
	const sx = origin.x + backX * (radius + gap);
	const sy = origin.y + backY * (radius + gap);
	const ex = sx + backX * length;
	const ey = sy + backY * length;
	const grad = ctx.createLinearGradient(sx, sy, ex, ey);
	grad.addColorStop(0, "#f7f4ee");
	grad.addColorStop(.05, "#d9c7a2");
	grad.addColorStop(.14, "#e4b15a");
	grad.addColorStop(1, "#5c371c");
	ctx.strokeStyle = grad;
	ctx.lineWidth = Math.max(4, radius * .32);
	ctx.lineCap = "butt";
	ctx.beginPath();
	ctx.moveTo(sx, sy);
	ctx.lineTo(ex, ey);
	ctx.stroke();
	ctx.fillStyle = "#24180f";
	ctx.beginPath();
	ctx.arc(sx, sy, Math.max(2.4, radius * .14), 0, Math.PI * 2);
	ctx.fill();
}
var opening = PRESETS[0];
function cloneBalls(balls) {
	return balls.map((ball) => ({ ...ball }));
}
function spinLabel(spin) {
	const follow = spin.y > .08 ? "Follow" : spin.y < -.08 ? "Draw" : null;
	const side = spin.x > .08 ? "Right english" : spin.x < -.08 ? "Left english" : null;
	if (!follow && !side) return "Center ball. Stun sends the cue square.";
	return [follow, side].filter(Boolean).join(" · ");
}
function OverlayApp() {
	const [balls, setBalls] = (0, import_react.useState)(() => cloneBalls(opening.balls));
	const [aim, setAim] = (0, import_react.useState)(opening.aim);
	const [power, setPower] = (0, import_react.useState)(opening.power);
	const [spin, setSpin] = (0, import_react.useState)(opening.spin);
	const [calledBallId, setCalledBallId] = (0, import_react.useState)(opening.calledBallId);
	const [calledPocketId, setCalledPocketId] = (0, import_react.useState)(opening.calledPocketId);
	const [showCall, setShowCall] = (0, import_react.useState)(true);
	const [showTracks, setShowTracks] = (0, import_react.useState)(true);
	const [presetId, setPresetId] = (0, import_react.useState)(opening.id);
	const [hand, setHand] = (0, import_react.useState)(false);
	const [history, setHistory] = (0, import_react.useState)([]);
	const [playback, setPlayback] = (0, import_react.useState)(null);
	const analysis = (0, import_react.useMemo)(() => analyze(balls, aim, power, spin, calledBallId, calledPocketId), [
		balls,
		aim,
		power,
		spin,
		calledBallId,
		calledPocketId
	]);
	const cuePocketed = balls.some((ball) => ball.n === 0 && ball.pocketed);
	const placing = hand || cuePocketed;
	const rolling = playback !== null;
	const preset = presetById(presetId);
	const called = balls.find((ball) => ball.id === calledBallId && !ball.pocketed);
	const up = balls.filter((ball) => ball.n !== 0 && !ball.pocketed).length;
	const title = rolling ? "Rolling" : cuePocketed ? "Cue in hand" : analysis.title;
	const detail = rolling ? "Tap the cloth to skip ahead." : placing && !cuePocketed ? "Tap the cloth to drop the cue ball." : analysis.detail;
	const cutText = rolling ? "—" : analysis.status === "bank" ? "1" : analysis.status === "combo" ? "2" : analysis.cutDeg == null ? "—" : String(Math.round(analysis.cutDeg));
	const cutCaption = analysis.status === "bank" ? "rail" : analysis.status === "combo" ? "ball" : "cut";
	function load(id) {
		const next = presetById(id);
		setBalls(cloneBalls(next.balls));
		setAim(next.aim);
		setPower(next.power);
		setSpin(next.spin);
		setCalledBallId(next.calledBallId);
		setCalledPocketId(next.calledPocketId);
		setPresetId(id);
		setHand(false);
		setPlayback(null);
	}
	function undo() {
		const prev = history[history.length - 1];
		if (!prev || rolling) return;
		setBalls(cloneBalls(prev.balls));
		setAim(prev.aim);
		setCalledBallId(prev.calledBallId);
		setCalledPocketId(prev.calledPocketId);
		setHistory((stack) => stack.slice(0, -1));
		setHand(false);
		setPlayback(null);
	}
	function stroke() {
		if (rolling || placing || power < .04) return;
		if (!balls.some((ball) => ball.n === 0 && !ball.pocketed)) return;
		setHistory((stack) => [...stack, {
			balls: cloneBalls(balls),
			aim,
			calledBallId,
			calledPocketId
		}].slice(-20));
		setPlayback(analysis.sim);
	}
	function finish(end) {
		setBalls(end);
		setPlayback(null);
		if (end.some((ball) => ball.n === 0 && ball.pocketed)) setHand(true);
		if (calledBallId && end.find((ball) => ball.id === calledBallId)?.pocketed) {
			const next = end.find((ball) => ball.n !== 0 && !ball.pocketed);
			setCalledBallId(next?.id ?? null);
			setCalledPocketId(next ? bestPocket(end, next) : null);
		}
	}
	const actions = (0, import_react.useRef)({
		stroke,
		undo,
		rolling: false
	});
	actions.current = {
		stroke,
		undo,
		rolling
	};
	(0, import_react.useEffect)(() => {
		function onKey(event) {
			const target = event.target;
			if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target instanceof HTMLButtonElement) return;
			if (actions.current.rolling) return;
			if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
				event.preventDefault();
				const step = event.shiftKey ? .004 : .014;
				setAim((value) => value + (event.key === "ArrowLeft" ? -step : step));
			} else if (event.key === " ") {
				event.preventDefault();
				actions.current.stroke();
			} else if ((event.key === "z" || event.key === "Z") && (event.metaKey || event.ctrlKey)) {
				event.preventDefault();
				actions.current.undo();
			}
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	const callLabel = called ? calledPocketId ? `${ballName(called.n)} · ${pocketById(calledPocketId).name}` : ballName(called.n) : "Tap a ball, then a pocket";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "app-shell flex h-dvh flex-col bg-bg text-cream",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex shrink-0 items-center justify-between gap-3 border-b border-line px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-sm tracking-widest text-gold",
				children: "8-BALL AIM OVERLAY"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl leading-none text-cream",
				children: "Cueline"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "hidden text-sm text-muted sm:block",
						children: [up, " up"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "flex size-11 items-center justify-center rounded-full border border-line bg-surface text-cream disabled:opacity-40",
						"aria-label": "Undo last stroke",
						disabled: history.length === 0 || rolling,
						onClick: undo,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, {
							className: "size-5",
							"aria-hidden": "true"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "flex size-11 items-center justify-center rounded-full border border-line bg-surface text-cream",
						"aria-label": "Reset this leave",
						onClick: () => load(presetId),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
							className: "size-5",
							"aria-hidden": "true"
						})
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-0 flex-1 flex-col lg:flex-row",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "table-stage relative min-h-0 flex-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PoolCanvas, {
					balls,
					aim,
					power,
					calledBallId,
					calledPocketId,
					showCall,
					showTracks,
					analysis,
					playback,
					placing,
					onPlaybackDone: finish,
					onAim: setAim,
					onMoveBall: (id, x, y) => {
						setBalls((prev) => prev.map((ball) => ball.id === id ? {
							...ball,
							...clampBall({
								x,
								y
							}, prev, id),
							pocketed: false
						} : ball));
					},
					onSelectBall: (id) => {
						const ball = balls.find((item) => item.id === id);
						if (!ball || ball.n === 0) return;
						setCalledBallId(id);
						setCalledPocketId(bestPocket(balls, ball));
					},
					onSelectPocket: setCalledPocketId,
					onPlaceCue: (x, y) => {
						setBalls((prev) => prev.map((ball) => ball.n === 0 ? {
							...ball,
							...clampBall({
								x,
								y
							}, prev, ball.id),
							pocketed: false
						} : ball));
						setHand(false);
					}
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "panel-scroll flex shrink-0 flex-col gap-3 overflow-y-auto border-t border-line px-4 py-3 lg:border-t-0 lg:border-l",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-3xl leading-none text-gold",
								"aria-live": "polite",
								children: title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-pretty text-muted",
								children: detail
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-4xl leading-none tabular-nums text-cream",
								children: cutText
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-sm tracking-widest text-muted",
								children: cutCaption
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-cream",
						children: callLabel
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mb-1 flex items-center justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "Power"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-cream",
								children: Math.round(power * 100)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "power-range",
							type: "range",
							min: .08,
							max: 1,
							step: .01,
							value: power,
							"aria-valuemin": 8,
							"aria-valuemax": 100,
							"aria-valuenow": Math.round(power * 100),
							"aria-label": "Shot power",
							disabled: rolling,
							onChange: (event) => setPower(Number(event.target.value))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpinPad, {
							spin,
							disabled: rolling,
							onChange: setSpin
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-w-0 flex-1 flex-col gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-pretty text-muted",
									children: spinLabel(spin)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-3 gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "flex h-11 items-center justify-center rounded-lg border border-line bg-surface text-cream",
											"aria-label": "Nudge aim counterclockwise",
											disabled: rolling,
											onClick: () => setAim((value) => value - .012),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
												className: "size-4",
												"aria-hidden": "true"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "flex h-11 items-center justify-center rounded-lg border border-line bg-surface text-sm text-cream",
											disabled: rolling,
											onClick: () => setSpin({
												x: 0,
												y: 0
											}),
											children: "Stun"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "flex h-11 items-center justify-center rounded-lg border border-line bg-surface text-cream",
											"aria-label": "Nudge aim clockwise",
											disabled: rolling,
											onClick: () => setAim((value) => value + .012),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, {
												className: "size-4",
												"aria-hidden": "true"
											})
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "stroke-btn h-12 rounded-lg font-display text-2xl tracking-wide",
									disabled: rolling || placing,
									onClick: stroke,
									children: rolling ? "Rolling" : "Stroke"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								pressed: showCall,
								onClick: () => setShowCall((value) => !value),
								children: "Call line"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
								pressed: showTracks,
								onClick: () => setShowTracks((value) => !value),
								children: "Tracks"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "h-11 rounded-lg border border-line bg-surface text-sm text-cream disabled:opacity-40",
								disabled: rolling,
								onClick: () => setHand(true),
								children: "Place cue"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-2 overflow-x-auto pb-1",
						children: PRESETS.map((item) => {
							const active = item.id === presetId;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: active ? "h-11 shrink-0 rounded-full bg-gold px-4 text-sm font-medium text-gold-ink" : "h-11 shrink-0 rounded-full border border-line bg-surface px-4 text-sm text-cream",
								"aria-pressed": active,
								onClick: () => load(item.id),
								children: item.name
							}, item.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-pretty text-muted",
						children: preset.hint
					})
				]
			})]
		})]
	});
}
function Toggle({ pressed, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": pressed,
		onClick,
		className: pressed ? "h-11 rounded-lg border border-gold bg-surface-2 text-sm text-cream" : "h-11 rounded-lg border border-line bg-surface text-sm text-muted",
		children
	});
}
function SpinPad({ spin, disabled, onChange }) {
	function fromEvent(event) {
		const rect = event.currentTarget.getBoundingClientRect();
		const x = (event.clientX - rect.left) / rect.width * 2 - 1;
		const y = (event.clientY - rect.top) / rect.height * 2 - 1;
		onChange({
			x: Math.min(1, Math.max(-1, x)),
			y: Math.min(1, Math.max(-1, -y))
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "spin-pad",
		role: "group",
		"aria-label": "Cue tip. Up is follow, down is draw, sides are english.",
		onPointerDown: (event) => {
			if (disabled) return;
			event.currentTarget.setPointerCapture(event.pointerId);
			fromEvent(event);
		},
		onPointerMove: (event) => {
			if (!event.currentTarget.hasPointerCapture(event.pointerId)) return;
			fromEvent(event);
		},
		onDoubleClick: () => onChange({
			x: 0,
			y: 0
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "spin-dot",
			style: {
				left: `${(spin.x + 1) / 2 * 100}%`,
				top: `${(-spin.y + 1) / 2 * 100}%`
			}
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OverlayApp, {});
}
//#endregion
export { Home as component };
