export const LENGTH = 2;
export const WIDTH = 1;
export const BALL_R = 0.04;
export const FRICTION = 1.05;
export const MIN_SPEED = 0.025;

export type PocketId = "tl" | "tr" | "bl" | "br" | "t" | "b";

export type Pocket = {
  id: PocketId;
  name: string;
  x: number;
  y: number;
  lip: number;
};

export type Ball = {
  id: string;
  n: number;
  x: number;
  y: number;
  pocketed: boolean;
};

export type Spin = { x: number; y: number };

export type Vec = { x: number; y: number };

export const POCKETS: Pocket[] = [
  { id: "tl", name: "Top left", x: 0, y: 0, lip: 0.062 },
  { id: "tr", name: "Top right", x: LENGTH, y: 0, lip: 0.062 },
  { id: "bl", name: "Bottom left", x: 0, y: WIDTH, lip: 0.062 },
  { id: "br", name: "Bottom right", x: LENGTH, y: WIDTH, lip: 0.062 },
  { id: "t", name: "Top side", x: LENGTH / 2, y: 0, lip: 0.05 },
  { id: "b", name: "Bottom side", x: LENGTH / 2, y: WIDTH, lip: 0.05 },
];

const MOUTH = 0.145;
const SIDE_MOUTH = 0.12;

export function pocketById(id: PocketId): Pocket {
  const pocket = POCKETS.find((p) => p.id === id);
  if (!pocket) throw new Error(`Unknown pocket ${id}`);
  return pocket;
}

export function kindOf(n: number): "cue" | "eight" | "solid" | "stripe" {
  if (n === 0) return "cue";
  if (n === 8) return "eight";
  if (n > 8) return "stripe";
  return "solid";
}

export function ballName(n: number): string {
  if (n === 0) return "Cue ball";
  if (n === 8) return "8-ball";
  return `${n}-ball`;
}

export function makeBall(n: number, x: number, y: number): Ball {
  return { id: n === 0 ? "cue" : `b${n}`, n, x, y, pocketed: false };
}

export function launchSpeed(power: number): number {
  return 0.55 + Math.min(1, Math.max(0, power)) * 2.85;
}

export function shotRange(power: number): number {
  const v = launchSpeed(power);
  return (v * v) / (2 * FRICTION);
}

export function sub(a: Vec, b: Vec): Vec {
  return { x: a.x - b.x, y: a.y - b.y };
}

export function add(a: Vec, b: Vec): Vec {
  return { x: a.x + b.x, y: a.y + b.y };
}

export function mul(a: Vec, s: number): Vec {
  return { x: a.x * s, y: a.y * s };
}

export function len(a: Vec): number {
  return Math.hypot(a.x, a.y);
}

export function norm(a: Vec): Vec {
  const l = len(a);
  if (l < 1e-8) return { x: 1, y: 0 };
  return { x: a.x / l, y: a.y / l };
}

export function clamp(v: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, v));
}

export function ghostForPot(ball: Vec, pocket: Vec): Vec {
  const d = norm(sub(pocket, ball));
  return sub(ball, mul(d, BALL_R * 2));
}

export function ghostPlayable(g: Vec): boolean {
  return (
    g.x >= BALL_R * 0.7 &&
    g.x <= LENGTH - BALL_R * 0.7 &&
    g.y >= BALL_R * 0.7 &&
    g.y <= WIDTH - BALL_R * 0.7
  );
}

export function cutAngle(cue: Vec, ghost: Vec, object: Vec): number {
  const a = sub(ghost, cue);
  const b = sub(object, ghost);
  const am = len(a);
  const bm = len(b);
  if (am < 1e-6 || bm < 1e-6) return 0;
  const cos = clamp((a.x * b.x + a.y * b.y) / (am * bm), -1, 1);
  return Math.acos(cos);
}

export function aimError(cue: Vec, ghost: Vec, aim: number): number {
  const ideal = Math.atan2(ghost.y - cue.y, ghost.x - cue.x);
  let d = ideal - aim;
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  return d;
}

export function segmentBlocked(
  a: Vec,
  b: Vec,
  balls: Ball[],
  ignore: Set<string>,
): boolean {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const len2 = dx * dx + dy * dy;
  if (len2 < 1e-8) return false;
  const limit = BALL_R * 2 - 0.004;
  for (const ball of balls) {
    if (ball.pocketed || ignore.has(ball.id)) continue;
    const t = ((ball.x - a.x) * dx + (ball.y - a.y) * dy) / len2;
    if (t <= 0.04 || t >= 0.96) continue;
    const px = a.x + dx * t;
    const py = a.y + dy * t;
    if (Math.hypot(ball.x - px, ball.y - py) < limit) return true;
  }
  return false;
}

export function bestPocket(balls: Ball[], ball: Ball): PocketId | null {
  const cue = balls.find((b) => b.n === 0 && !b.pocketed);
  let best: { id: PocketId; score: number } | null = null;
  for (const pocket of POCKETS) {
    const ghost = ghostForPot(ball, pocket);
    if (!ghostPlayable(ghost)) continue;
    if (segmentBlocked(ball, pocket, balls, new Set([ball.id]))) continue;
    if (cue && segmentBlocked(cue, ghost, balls, new Set([ball.id, cue.id]))) continue;
    const cut = cue ? cutAngle(cue, ghost, ball) : 0;
    if (cut > 1.22) continue;
    const travel = cue ? len(sub(ghost, cue)) : 0;
    const score = cut + travel * 0.12;
    if (!best || score < best.score) best = { id: pocket.id, score };
  }
  return best?.id ?? null;
}

export function clampBall(pos: Vec, balls: Ball[], id: string): Vec {
  let x = clamp(pos.x, BALL_R, LENGTH - BALL_R);
  let y = clamp(pos.y, BALL_R, WIDTH - BALL_R);
  for (let pass = 0; pass < 3; pass++) {
    for (const other of balls) {
      if (other.id === id || other.pocketed) continue;
      const dx = x - other.x;
      const dy = y - other.y;
      const d = Math.hypot(dx, dy);
      const min = BALL_R * 2 + 0.0015;
      if (d < min) {
        const nx = d < 1e-6 ? 1 : dx / d;
        const ny = d < 1e-6 ? 0 : dy / d;
        x = other.x + nx * min;
        y = other.y + ny * min;
      }
    }
    x = clamp(x, BALL_R, LENGTH - BALL_R);
    y = clamp(y, BALL_R, WIDTH - BALL_R);
  }
  return { x, y };
}

type Live = Ball & { vx: number; vy: number };

export type Frame = { xs: number[]; ys: number[]; down: boolean[] };

export type Track = { id: string; pts: Vec[] };

export type SimResult = {
  frames: Frame[];
  tracks: Track[];
  pocketed: { id: string; pocket: PocketId }[];
  firstContact: { id: string; ghost: Vec } | null;
  endBalls: Ball[];
  bounces: Record<string, number>;
};

function inMouth(x: number, y: number): boolean {
  const nearEnd = x < MOUTH || x > LENGTH - MOUTH;
  const nearSide = y < MOUTH || y > WIDTH - MOUTH;
  if (nearEnd && nearSide) return true;
  if (Math.abs(x - LENGTH / 2) < SIDE_MOUTH && nearSide) return true;
  return false;
}

function nearestPocket(x: number, y: number): Pocket | null {
  let best: Pocket | null = null;
  let bestD = 0.16;
  for (const pocket of POCKETS) {
    const d = Math.hypot(x - pocket.x, y - pocket.y);
    if (d < bestD) {
      best = pocket;
      bestD = d;
    }
  }
  return best;
}

export function simulate(
  balls: Ball[],
  aim: number,
  power: number,
  spin: Spin,
): SimResult {
  const ordered = balls.map((b) => ({ ...b }));
  const live: Live[] = ordered.map((b) => ({ ...b, vx: 0, vy: 0 }));
  const index = new Map(live.map((b, i) => [b.id, i]));
  const cue = live.find((b) => b.n === 0 && !b.pocketed);
  const frames: Frame[] = [];
  const samples = new Map<string, Vec[]>();
  for (const ball of live) samples.set(ball.id, [{ x: ball.x, y: ball.y }]);
  const pocketed: { id: string; pocket: PocketId }[] = [];
  const bounces: Record<string, number> = {};
  let firstContact: SimResult["firstContact"] = null;
  let spinUsed = false;

  const snap = () => {
    frames.push({
      xs: live.map((b) => b.x),
      ys: live.map((b) => b.y),
      down: live.map((b) => b.pocketed),
    });
  };

  snap();

  if (!cue || power < 0.03) {
    return {
      frames,
      tracks: [],
      pocketed,
      firstContact,
      endBalls: ordered,
      bounces,
    };
  }

  const speed = launchSpeed(power);
  cue.vx = Math.cos(aim) * speed;
  cue.vy = Math.sin(aim) * speed;

  const dt = 1 / 120;
  let idle = 0;

  for (let step = 0; step < 840; step++) {
    let moving = false;
    const prev = live.map((b) => ({ x: b.x, y: b.y }));

    for (const ball of live) {
      if (ball.pocketed) continue;
      const sp = Math.hypot(ball.vx, ball.vy);
      if (sp < MIN_SPEED) {
        ball.vx = 0;
        ball.vy = 0;
        continue;
      }
      moving = true;
      const next = Math.max(0, sp - FRICTION * dt);
      const k = sp > 0 ? next / sp : 0;
      ball.vx *= k;
      ball.vy *= k;
      ball.x += ball.vx * dt;
      ball.y += ball.vy * dt;
    }

    for (let iter = 0; iter < 4; iter++) {
      for (let i = 0; i < live.length; i++) {
        for (let j = i + 1; j < live.length; j++) {
          const a = live[i];
          const b = live[j];
          if (a.pocketed || b.pocketed) continue;
          let dx = b.x - a.x;
          let dy = b.y - a.y;
          let dist = Math.hypot(dx, dy);
          const min = BALL_R * 2;
          if (dist < 1e-8) {
            dx = min;
            dy = 0;
            dist = min;
          }
          if (dist >= min) continue;
          const nx = dx / dist;
          const ny = dy / dist;
          const overlap = min - dist;
          a.x -= nx * overlap * 0.5;
          a.y -= ny * overlap * 0.5;
          b.x += nx * overlap * 0.5;
          b.y += ny * overlap * 0.5;
          const rel = (a.vx - b.vx) * nx + (a.vy - b.vy) * ny;
          if (rel <= 0.0001) continue;
          a.vx -= nx * rel;
          a.vy -= ny * rel;
          b.vx += nx * rel;
          b.vy += ny * rel;

          const cueBall = a.n === 0 ? a : b.n === 0 ? b : null;
          const other = cueBall === a ? b : cueBall === b ? a : null;
          if (cueBall && other && !spinUsed && iter === 0) {
            spinUsed = true;
            const cnx = other.x - cueBall.x;
            const cny = other.y - cueBall.y;
            const cl = Math.hypot(cnx, cny) || 1;
            const nxC = cnx / cl;
            const nyC = cny / cl;
            const follow = clamp(spin.y, -1, 1);
            const english = clamp(spin.x, -1, 1);
            cueBall.vx += nxC * rel * follow * 0.82;
            cueBall.vy += nyC * rel * follow * 0.82;
            cueBall.vx += -nyC * english * rel * 0.28;
            cueBall.vy += nxC * english * rel * 0.28;
            const throwAng = -english * 0.07;
            const ox = other.vx;
            const oy = other.vy;
            const c = Math.cos(throwAng);
            const s = Math.sin(throwAng);
            other.vx = ox * c - oy * s;
            other.vy = ox * s + oy * c;
            firstContact = {
              id: other.id,
              ghost: { x: cueBall.x, y: cueBall.y },
            };
          }
        }
      }
    }

    for (let i = 0; i < live.length; i++) {
      const ball = live[i];
      if (ball.pocketed) continue;
      const before = prev[i];
      const sp = Math.hypot(ball.vx, ball.vy);

      if (sp > 0.05) {
        const hole = enteredPocket(before, ball);
        if (hole) {
          ball.pocketed = true;
          ball.vx = 0;
          ball.vy = 0;
          ball.x = hole.x;
          ball.y = hole.y;
          pocketed.push({ id: ball.id, pocket: hole.id });
          continue;
        }
      }

      if (inMouth(ball.x, ball.y)) {
        const hole = nearestPocket(ball.x, ball.y);
        if (hole && Math.hypot(ball.x - hole.x, ball.y - hole.y) < 0.1 && sp > 0.08) {
          const pull = 2.4 * dt;
          ball.vx += (hole.x - ball.x) * pull;
          ball.vy += (hole.y - ball.y) * pull;
        }
        continue;
      }

      const damp = 0.74;
      let hit = false;
      if (ball.x < BALL_R) {
        ball.x = BALL_R;
        ball.vx = Math.abs(ball.vx) * damp;
        hit = true;
      } else if (ball.x > LENGTH - BALL_R) {
        ball.x = LENGTH - BALL_R;
        ball.vx = -Math.abs(ball.vx) * damp;
        hit = true;
      }
      if (ball.y < BALL_R) {
        ball.y = BALL_R;
        ball.vy = Math.abs(ball.vy) * damp;
        hit = true;
      } else if (ball.y > WIDTH - BALL_R) {
        ball.y = WIDTH - BALL_R;
        ball.vy = -Math.abs(ball.vy) * damp;
        hit = true;
      }
      if (hit) bounces[ball.id] = (bounces[ball.id] ?? 0) + 1;
    }

    if (step % 2 === 0) {
      snap();
      for (const ball of live) {
        if (ball.pocketed) continue;
        const pts = samples.get(ball.id);
        if (!pts) continue;
        const last = pts[pts.length - 1];
        if (Math.hypot(ball.x - last.x, ball.y - last.y) > 0.01) {
          pts.push({ x: ball.x, y: ball.y });
        }
      }
    }

    if (!moving) {
      idle++;
      if (idle > 8) break;
    } else {
      idle = 0;
    }
  }

  snap();

  const tracks: Track[] = [];
  for (const [id, pts] of samples) {
    if (pts.length < 2) continue;
    let travel = 0;
    for (let i = 1; i < pts.length; i++) travel += Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
    if (travel < 0.03) continue;
    tracks.push({ id, pts });
  }

  const endBalls: Ball[] = live.map((b) => ({
    id: b.id,
    n: b.n,
    x: clamp(b.x, BALL_R, LENGTH - BALL_R),
    y: clamp(b.y, BALL_R, WIDTH - BALL_R),
    pocketed: b.pocketed,
  }));

  return { frames, tracks, pocketed, firstContact, endBalls, bounces };
}

function enteredPocket(prev: Vec, ball: Live): Pocket | null {
  for (const pocket of POCKETS) {
    const d1 = Math.hypot(ball.x - pocket.x, ball.y - pocket.y);
    if (d1 > pocket.lip) continue;
    const offFelt =
      ball.x < BALL_R * 0.45 ||
      ball.x > LENGTH - BALL_R * 0.45 ||
      ball.y < BALL_R * 0.45 ||
      ball.y > WIDTH - BALL_R * 0.45;
    if (!offFelt && d1 > pocket.lip * 0.5) continue;
    const d0 = Math.hypot(prev.x - pocket.x, prev.y - pocket.y);
    if (d1 <= d0 || d0 > pocket.lip) return pocket;
  }
  return null;
}

export type CallInfo = {
  ghost: Vec;
  cut: number;
  error: number;
  blockedBall: boolean;
  blockedCue: boolean;
  playable: boolean;
  reach: number;
  range: number;
};

export type ShotStatus =
  | "rolling"
  | "hand"
  | "line"
  | "make"
  | "bank"
  | "combo"
  | "scratch"
  | "wrong"
  | "short"
  | "blocked"
  | "thin"
  | "off"
  | "miss"
  | "clear";

export type Analysis = {
  sim: SimResult;
  call: CallInfo | null;
  status: ShotStatus;
  title: string;
  detail: string;
  cutDeg: number | null;
};

export function analyze(
  balls: Ball[],
  aim: number,
  power: number,
  spin: Spin,
  calledBallId: string | null,
  calledPocketId: PocketId | null,
): Analysis {
  const sim = simulate(balls, aim, power, spin);
  const cue = balls.find((b) => b.n === 0 && !b.pocketed);
  const called = balls.find((b) => b.id === calledBallId && !b.pocketed);
  const pocket = calledPocketId ? pocketById(calledPocketId) : null;
  let call: CallInfo | null = null;
  if (cue && called && pocket) {
    const ghost = ghostForPot(called, pocket);
    call = {
      ghost,
      cut: cutAngle(cue, ghost, called),
      error: aimError(cue, ghost, aim),
      blockedBall: segmentBlocked(called, pocket, balls, new Set([called.id])),
      blockedCue: segmentBlocked(cue, ghost, balls, new Set([called.id, cue.id])),
      playable: ghostPlayable(ghost),
      reach: len(sub(ghost, cue)),
      range: shotRange(power),
    };
  }

  const cueDown = sim.pocketed.some((p) => p.id === "cue");
  const calledHit = called ? sim.pocketed.find((p) => p.id === called.id) : undefined;
  const cutDeg = call ? (call.cut * 180) / Math.PI : null;
  const offDeg = call ? Math.abs((call.error * 180) / Math.PI) : null;

  let status: ShotStatus = "miss";
  let title = "No contact";
  let detail = "The cue ball never finds a ball.";

  if (!balls.some((b) => b.n !== 0 && !b.pocketed)) {
    status = "clear";
    title = "Table clear";
    detail = "Re-rack when you want another leave.";
  } else if (!cue) {
    status = "hand";
    title = "Cue in hand";
    detail = "Tap the cloth to place the cue ball.";
  } else if (cueDown && calledHit) {
    status = "scratch";
    title = "Scratch";
    detail = "The called ball drops, and so does the cue.";
  } else if (cueDown) {
    status = "scratch";
    title = "Scratch";
    detail = "The cue ball finds a pocket on this line.";
  } else if (called && calledHit && pocket && calledHit.pocket === pocket.id) {
    const banked = (sim.bounces[called.id] ?? 0) > 0;
    const combo = sim.firstContact != null && sim.firstContact.id !== called.id;
    if (combo) {
      status = "combo";
      title = "Combo";
      detail = "The first ball sends the called ball in.";
    } else if (banked) {
      status = "bank";
      title = "Bank";
      detail = "Off the cushion and into the called pocket.";
    } else if (offDeg != null && offDeg < 1.4) {
      status = "line";
      title = "On the line";
      detail = "Ghost ball and cue track agree.";
    } else {
      status = "make";
      title = "Make";
      detail = "This stroke pots the called ball.";
    }
  } else if (called && calledHit && pocket) {
    status = "wrong";
    title = "Wrong pocket";
    detail = `It falls in the ${pocketById(calledHit.pocket).name.toLowerCase()} pocket.`;
  } else if (called && calledHit) {
    status = "make";
    title = "Pocket";
    detail = `The ${ballName(called.n)} finds the ${pocketById(calledHit.pocket).name.toLowerCase()}.`;
  } else if (call && (call.blockedBall || call.blockedCue)) {
    status = "blocked";
    title = "Blocked";
    detail = call.blockedBall
      ? "Another ball sits on the way to the pocket."
      : "The path to the ghost ball is not clear.";
  } else if (call && !call.playable) {
    status = "blocked";
    title = "No ghost";
    detail = "That pocket needs the cue ball off the table.";
  } else if (call && call.cut > 1.2) {
    status = "thin";
    title = "Too thin";
    detail = "The cut is past what a center-ball hit can hold.";
  } else if (call && call.reach > call.range * 0.96) {
    status = "short";
    title = "Short";
    detail = "Add power if you want the cue to reach.";
  } else if (call && offDeg != null && offDeg >= 1.4) {
    status = "off";
    title = "Off the ghost";
    detail = `${offDeg.toFixed(1)}° away from the pot line.`;
  } else if (sim.firstContact) {
    const calledShot = Boolean(called && pocket);
    status = "miss";
    title = calledShot ? "Miss" : "Track";
    detail = calledShot
      ? "Contact, then the object ball drifts wide."
      : "White follows the cue. Gold follows the first ball it meets.";
  }

  return { sim, call, status, title, detail, cutDeg };
}

export type Preset = {
  id: string;
  name: string;
  hint: string;
  balls: Ball[];
  aim: number;
  power: number;
  spin: Spin;
  calledBallId: string | null;
  calledPocketId: PocketId | null;
};

function aimToward(from: Vec, to: Vec): number {
  return Math.atan2(to.y - from.y, to.x - from.x);
}

function safeCue(pos: Vec, others: Ball[]): Ball {
  const placed = clampBall(pos, others, "cue");
  return makeBall(0, placed.x, placed.y);
}

export function cornerPreset(): Preset {
  const pocket = pocketById("tr");
  const ball = makeBall(3, 1.28, 0.34);
  const ghost = ghostForPot(ball, pocket);
  const dir = norm(sub(ball, ghost));
  const eight = makeBall(8, 1.58, 0.74);
  const nine = makeBall(11, 0.86, 0.24);
  const cue = safeCue(sub(ghost, mul(dir, 0.58)), [ball, eight, nine]);
  return {
    id: "corner",
    name: "Corner",
    hint: "A called corner. Match the gold ghost.",
    balls: [cue, ball, eight, nine],
    aim: aimToward(cue, ghost),
    power: 0.62,
    spin: { x: 0, y: 0 },
    calledBallId: ball.id,
    calledPocketId: "tr",
  };
}

export function sidePreset(): Preset {
  const pocket = pocketById("t");
  const ball = makeBall(5, 1.12, 0.46);
  const ghost = ghostForPot(ball, pocket);
  const dir = norm(sub(ball, ghost));
  const eight = makeBall(8, 1.66, 0.8);
  const ten = makeBall(10, 0.48, 0.22);
  const cue = safeCue(sub(ghost, mul(dir, 0.3)), [ball, eight, ten]);
  return {
    id: "side",
    name: "Side",
    hint: "Straight into the side pocket.",
    balls: [cue, ball, eight, ten],
    aim: aimToward(cue, ghost),
    power: 0.6,
    spin: { x: 0, y: 0 },
    calledBallId: ball.id,
    calledPocketId: "t",
  };
}

export function thinPreset(): Preset {
  const cue = makeBall(0, 0.42, 0.3);
  const ball = makeBall(1, 1.3, 0.55);
  const eight = makeBall(8, 0.72, 0.8);
  const stripe = makeBall(9, 1.72, 0.2);
  return {
    id: "thin",
    name: "Thin cut",
    hint: "The line is on the ball. Slide it onto the ghost.",
    balls: [cue, ball, eight, stripe],
    aim: aimToward(cue, ball),
    power: 0.7,
    spin: { x: 0, y: 0 },
    calledBallId: ball.id,
    calledPocketId: "br",
  };
}

export function comboPreset(): Preset {
  const pocket = pocketById("br");
  const target = makeBall(6, 1.42, 0.62);
  const dir = norm(sub(pocket, target));
  const first = makeBall(2, target.x - dir.x * (BALL_R * 2 + 0.012), target.y - dir.y * (BALL_R * 2 + 0.012));
  const ghost = ghostForPot(first, add(first, dir));
  const cue = safeCue(sub(ghost, mul(dir, 0.48)), [target, first, makeBall(8, 0.55, 0.28)]);
  const eight = makeBall(8, 0.55, 0.28);
  return {
    id: "combo",
    name: "Combo",
    hint: "Cue hits the 2, the 2 hits the 6.",
    balls: [cue, first, target, eight],
    aim: aimToward(cue, ghostForPot(first, target)),
    power: 0.78,
    spin: { x: 0, y: 0 },
    calledBallId: target.id,
    calledPocketId: "br",
  };
}

export function bankPreset(): Preset {
  const ball = makeBall(4, 0.8, 0.5);
  const cue = makeBall(0, 1.06, 0.15);
  const eight = makeBall(8, 1.64, 0.78);
  const mirror = { x: 0, y: 2 };
  const dir = norm(sub(mirror, ball));
  const ghost = sub(ball, mul(dir, BALL_R * 2));
  return {
    id: "bank",
    name: "Bank",
    hint: "One rail off the bottom into the top left.",
    balls: [cue, ball, eight],
    aim: aimToward(cue, ghost),
    power: 0.88,
    spin: { x: 0, y: 0 },
    calledBallId: ball.id,
    calledPocketId: "tl",
  };
}

export function eightPreset(): Preset {
  const pocket = pocketById("br");
  const ball = makeBall(8, 1.36, 0.62);
  const ghost = ghostForPot(ball, pocket);
  const dir = norm(sub(ball, ghost));
  const cue = safeCue(sub(ghost, mul(dir, 0.64)), [ball]);
  return {
    id: "eight",
    name: "8-ball",
    hint: "Game ball. Keep the cue out of the pocket.",
    balls: [cue, ball],
    aim: aimToward(cue, ghost),
    power: 0.6,
    spin: { x: 0, y: 0 },
    calledBallId: ball.id,
    calledPocketId: "br",
  };
}

export function rackPreset(): Preset {
  const gap = BALL_R * 2.05;
  const apex = { x: 1.52, y: 0.5 };
  const numbers = [
    [1],
    [9, 2],
    [10, 8, 3],
    [11, 4, 12, 5],
    [6, 13, 7, 14, 15],
  ];
  const balls: Ball[] = [];
  for (let row = 0; row < numbers.length; row++) {
    for (let col = 0; col < numbers[row].length; col++) {
      const n = numbers[row][col];
      const x = apex.x + row * gap * Math.cos(Math.PI / 6);
      const y = apex.y + (col - row / 2) * gap;
      balls.push(makeBall(n, x, y));
    }
  }
  const cue = makeBall(0, 0.48, 0.5);
  balls.unshift(cue);
  const one = balls.find((b) => b.n === 1)!;
  const pocket = bestPocket(balls, one);
  const ghost = pocket ? ghostForPot(one, pocketById(pocket)) : one;
  return {
    id: "rack",
    name: "Full rack",
    hint: "Open the 1, or drag any ball out and call it.",
    balls,
    aim: aimToward(cue, ghost),
    power: 0.92,
    spin: { x: 0, y: 0 },
    calledBallId: one.id,
    calledPocketId: pocket,
  };
}

export const PRESETS: Preset[] = [
  cornerPreset(),
  sidePreset(),
  thinPreset(),
  comboPreset(),
  bankPreset(),
  eightPreset(),
  rackPreset(),
];

export function presetById(id: string): Preset {
  return PRESETS.find((p) => p.id === id) ?? PRESETS[0];
}
