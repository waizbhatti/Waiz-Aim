import { useEffect, useRef, type PointerEvent as ReactPointerEvent } from "react";
import {
  BALL_R,
  LENGTH,
  POCKETS,
  WIDTH,
  type Analysis,
  type Ball,
  type PocketId,
  type SimResult,
} from "@/lib/pool/model";

type Layout = {
  portrait: boolean;
  scale: number;
  rail: number;
  ox: number;
  oy: number;
  fx: number;
  fy: number;
  feltW: number;
  feltH: number;
};

type Drag =
  | { kind: "ball"; id: string; moved: boolean; px: number; py: number }
  | { kind: "aim"; moved: boolean; pocket: PocketId | null; px: number; py: number }
  | { kind: "place"; px: number; py: number };

const BALL_COLORS: Record<number, string> = {
  1: "#f0d23c",
  2: "#3a78d8",
  3: "#e23d3d",
  4: "#7a4fd0",
  5: "#ef8a2a",
  6: "#1f8f52",
  7: "#8d3140",
  8: "#141414",
  9: "#f0d23c",
  10: "#3a78d8",
  11: "#e23d3d",
  12: "#7a4fd0",
  13: "#ef8a2a",
  14: "#1f8f52",
  15: "#8d3140",
};

const CREAM = "#f3efe4";
const GOLD = "#e4b15a";

let noiseCanvas: HTMLCanvasElement | null = null;

function feltNoise(): HTMLCanvasElement {
  if (noiseCanvas) return noiseCanvas;
  const canvas = document.createElement("canvas");
  canvas.width = 180;
  canvas.height = 180;
  const ctx = canvas.getContext("2d");
  if (!ctx) return canvas;
  for (let i = 0; i < 900; i++) {
    const light = Math.random() > 0.5;
    ctx.fillStyle = light ? "rgba(255,255,255,0.045)" : "rgba(0,0,0,0.05)";
    ctx.fillRect(Math.random() * 180, Math.random() * 180, 1.2, 1.2);
  }
  noiseCanvas = canvas;
  return canvas;
}

function layoutFor(width: number, height: number): Layout {
  const portrait = height > width * 0.92 && width < 900;
  const rail = Math.max(14, Math.min(width, height) * 0.034);
  const margin = 8;
  const aspect = portrait ? WIDTH / LENGTH : LENGTH / WIDTH;
  const maxW = Math.max(40, width - margin * 2 - rail * 2);
  const maxH = Math.max(40, height - margin * 2 - rail * 2);
  let feltW: number;
  let feltH: number;
  if (maxW / maxH > aspect) {
    feltH = maxH;
    feltW = feltH * aspect;
  } else {
    feltW = maxW;
    feltH = feltW / aspect;
  }
  const scale = portrait ? feltW / WIDTH : feltW / LENGTH;
  const outerW = feltW + rail * 2;
  const outerH = feltH + rail * 2;
  const ox = (width - outerW) / 2;
  const oy = (height - outerH) / 2;
  return { portrait, scale, rail, ox, oy, fx: ox + rail, fy: oy + rail, feltW, feltH };
}

function toScreen(x: number, y: number, layout: Layout): { x: number; y: number } {
  if (!layout.portrait) return { x: layout.fx + x * layout.scale, y: layout.fy + y * layout.scale };
  return { x: layout.fx + y * layout.scale, y: layout.fy + x * layout.scale };
}

function toTable(sx: number, sy: number, layout: Layout): { x: number; y: number } {
  if (!layout.portrait) {
    return { x: (sx - layout.fx) / layout.scale, y: (sy - layout.fy) / layout.scale };
  }
  return { x: (sy - layout.fy) / layout.scale, y: (sx - layout.fx) / layout.scale };
}

function aimOnScreen(aim: number, portrait: boolean): { x: number; y: number } {
  const tx = Math.cos(aim);
  const ty = Math.sin(aim);
  return portrait ? { x: ty, y: tx } : { x: tx, y: ty };
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + w, y, x + w, y + h, radius);
  ctx.arcTo(x + w, y + h, x, y + h, radius);
  ctx.arcTo(x, y + h, x, y, radius);
  ctx.arcTo(x, y, x + w, y, radius);
  ctx.closePath();
}

function shade(hex: string, amt: number): string {
  const n = Number.parseInt(hex.slice(1), 16);
  const r = Math.min(255, Math.max(0, ((n >> 16) & 255) + amt));
  const g = Math.min(255, Math.max(0, ((n >> 8) & 255) + amt));
  const b = Math.min(255, Math.max(0, (n & 255) + amt));
  return `rgb(${r} ${g} ${b})`;
}

function drawDots(
  ctx: CanvasRenderingContext2D,
  pts: { x: number; y: number }[],
  color: string,
  radius: number,
) {
  if (pts.length < 2) return;
  const spacing = 12;
  let carry = 0;
  ctx.fillStyle = color;
  for (let i = 1; i < pts.length; i++) {
    const a = pts[i - 1];
    const b = pts[i];
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    const dist = Math.hypot(dx, dy);
    if (dist < 0.001) continue;
    let traveled = carry;
    while (traveled < dist) {
      const t = traveled / dist;
      ctx.beginPath();
      ctx.arc(a.x + dx * t, a.y + dy * t, radius, 0, Math.PI * 2);
      ctx.fill();
      traveled += spacing;
    }
    carry = traveled - dist;
  }
}

function drawBall(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, ball: Ball) {
  ctx.beginPath();
  ctx.arc(x + r * 0.12, y + r * 0.2, r, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(0,0,0,0.28)";
  ctx.fill();

  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  const stripe = ball.n > 8;
  const color = BALL_COLORS[ball.n] ?? CREAM;
  if (ball.n === 0) {
    const g = ctx.createRadialGradient(x - r * 0.35, y - r * 0.4, r * 0.1, x, y, r);
    g.addColorStop(0, "#ffffff");
    g.addColorStop(0.72, "#f3efe4");
    g.addColorStop(1, "#cfc6b6");
    ctx.fillStyle = g;
    ctx.fill();
  } else if (stripe) {
    ctx.save();
    ctx.clip();
    ctx.fillStyle = "#f7f4ee";
    ctx.fillRect(x - r, y - r, r * 2, r * 2);
    ctx.fillStyle = color;
    ctx.fillRect(x - r, y - r * 0.46, r * 2, r * 0.92);
    ctx.restore();
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.strokeStyle = "rgba(0,0,0,0.25)";
    ctx.lineWidth = 1;
    ctx.stroke();
  } else {
    const g = ctx.createRadialGradient(x - r * 0.32, y - r * 0.38, r * 0.1, x, y, r);
    g.addColorStop(0, ball.n === 8 ? "#4a4a4a" : shade(color, 70));
    g.addColorStop(0.55, color);
    g.addColorStop(1, shade(color, -40));
    ctx.fillStyle = g;
    ctx.fill();
  }

  if (ball.n !== 0 && r > 7) {
    ctx.beginPath();
    ctx.arc(x, y, r * 0.46, 0, Math.PI * 2);
    ctx.fillStyle = "#f7f4ee";
    ctx.fill();
    ctx.fillStyle = "#1a140c";
    ctx.font = `700 ${Math.max(8, r * 0.72)}px "Barlow Condensed", sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(String(ball.n), x, y + r * 0.04);
  }

  ctx.beginPath();
  ctx.ellipse(x - r * 0.28, y - r * 0.34, r * 0.26, r * 0.14, -0.7, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(255,255,255,0.45)";
  ctx.fill();
}

export function PoolCanvas({
  balls,
  aim,
  power,
  calledBallId,
  calledPocketId,
  showCall,
  showTracks,
  analysis,
  playback,
  placing,
  onPlaybackDone,
  onAim,
  onMoveBall,
  onSelectBall,
  onSelectPocket,
  onPlaceCue,
}: {
  balls: Ball[];
  aim: number;
  power: number;
  calledBallId: string | null;
  calledPocketId: PocketId | null;
  showCall: boolean;
  showTracks: boolean;
  analysis: Analysis;
  playback: SimResult | null;
  placing: boolean;
  onPlaybackDone: (end: Ball[]) => void;
  onAim: (aim: number) => void;
  onMoveBall: (id: string, x: number, y: number) => void;
  onSelectBall: (id: string) => void;
  onSelectPocket: (id: PocketId) => void;
  onPlaceCue: (x: number, y: number) => void;
}) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const propsRef = useRef({
    balls,
    aim,
    power,
    calledBallId,
    calledPocketId,
    showCall,
    showTracks,
    analysis,
    playback,
    placing,
    onPlaybackDone,
    onAim,
    onMoveBall,
    onSelectBall,
    onSelectPocket,
    onPlaceCue,
  });
  propsRef.current = {
    balls,
    aim,
    power,
    calledBallId,
    calledPocketId,
    showCall,
    showTracks,
    analysis,
    playback,
    placing,
    onPlaybackDone,
    onAim,
    onMoveBall,
    onSelectBall,
    onSelectPocket,
    onPlaceCue,
  };

  const dragRef = useRef<Drag | null>(null);
  const playRef = useRef<{ sim: SimResult | null; started: number; done: boolean }>({
    sim: null,
    started: 0,
    done: false,
  });

  useEffect(() => {
    const wrap = wrapRef.current;
    const canvas = canvasRef.current;
    if (!wrap || !canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let frame = 0;
    const draw = (now: number) => {
      const rect = wrap.getBoundingClientRect();
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      const w = Math.max(1, rect.width);
      const h = Math.max(1, rect.height);
      const pw = Math.floor(w * dpr);
      const ph = Math.floor(h * dpr);
      if (canvas.width !== pw || canvas.height !== ph) {
        canvas.width = pw;
        canvas.height = ph;
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);

      const layout = layoutFor(w, h);
      const props = propsRef.current;
      const playing = props.playback;
      if (playing && playRef.current.sim !== playing) {
        playRef.current = { sim: playing, started: now, done: false };
        if (window.matchMedia("(prefers-reduced-motion: reduce)").matches || playing.frames.length < 2) {
          playRef.current.done = true;
          props.onPlaybackDone(playing.endBalls);
        }
      }
      if (!playing) playRef.current = { sim: null, started: 0, done: false };

      let view: Ball[] = props.balls;
      if (playing && playRef.current.sim === playing) {
        const last = playing.frames.length - 1;
        const idx = playRef.current.done
          ? last
          : Math.min(last, Math.floor((now - playRef.current.started) / 14));
        const snap = playing.frames[idx];
        if (snap) {
          view = props.balls.map((ball, i) => ({
            ...ball,
            x: snap.xs[i] ?? ball.x,
            y: snap.ys[i] ?? ball.y,
            pocketed: snap.down[i] ?? ball.pocketed,
          }));
        }
        if (!playRef.current.done && idx >= last) {
          playRef.current.done = true;
          props.onPlaybackDone(playing.endBalls);
        }
      }

      paintTable(ctx, layout);
      const rolling = Boolean(playing && !playRef.current.done);
      if (!rolling) paintGuides(ctx, layout, props);
      for (const ball of view) {
        if (ball.pocketed) continue;
        const p = toScreen(ball.x, ball.y, layout);
        const radius = BALL_R * layout.scale;
        drawBall(ctx, p.x, p.y, radius, ball);
        if (ball.id === props.calledBallId) {
          ctx.beginPath();
          ctx.arc(p.x, p.y, radius + 4, 0, Math.PI * 2);
          ctx.strokeStyle = GOLD;
          ctx.lineWidth = 2;
          ctx.stroke();
        }
      }
      if (!rolling) paintCue(ctx, layout, view, props.aim, props.power);

      frame = requestAnimationFrame(draw);
    };
    frame = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(frame);
  }, []);

  function localPoint(event: ReactPointerEvent<HTMLCanvasElement>) {
    const rect = event.currentTarget.getBoundingClientRect();
    return { x: event.clientX - rect.left, y: event.clientY - rect.top, w: rect.width, h: rect.height };
  }

  function hitBall(px: number, py: number, layout: Layout, list: Ball[]): Ball | null {
    const slop = 10;
    for (let i = list.length - 1; i >= 0; i--) {
      const ball = list[i];
      if (ball.pocketed) continue;
      const p = toScreen(ball.x, ball.y, layout);
      if (Math.hypot(p.x - px, p.y - py) <= BALL_R * layout.scale + slop) return ball;
    }
    return null;
  }

  function hitPocket(px: number, py: number, layout: Layout): PocketId | null {
    let best: PocketId | null = null;
    let bestD = Number.POSITIVE_INFINITY;
    for (const pocket of POCKETS) {
      const p = toScreen(pocket.x, pocket.y, layout);
      const d = Math.hypot(p.x - px, p.y - py);
      const limit = Math.max(24, pocket.lip * layout.scale * 1.8);
      if (d < limit && d < bestD) {
        best = pocket.id;
        bestD = d;
      }
    }
    return best;
  }

  return (
    <div ref={wrapRef} className="absolute inset-0">
      <canvas
        ref={canvasRef}
        className="h-full w-full touch-none"
        role="img"
        aria-label="8-ball table. Drag the cloth to aim, drag a ball to move it, tap a pocket to call it."
        onPointerDown={(event: ReactPointerEvent<HTMLCanvasElement>) => {
          if (propsRef.current.playback) return;
          const point = localPoint(event);
          const layout = layoutFor(point.w, point.h);
          const table = toTable(point.x, point.y, layout);
          const ball = hitBall(point.x, point.y, layout, propsRef.current.balls);
          const pocket = hitPocket(point.x, point.y, layout);
          event.currentTarget.setPointerCapture(event.pointerId);
          if (propsRef.current.placing && !ball) {
            dragRef.current = { kind: "place", px: point.x, py: point.y };
            return;
          }
          if (ball) {
            dragRef.current = { kind: "ball", id: ball.id, moved: false, px: point.x, py: point.y };
            return;
          }
          dragRef.current = { kind: "aim", moved: false, pocket, px: point.x, py: point.y };
          if (!propsRef.current.placing) {
            const cue = propsRef.current.balls.find((b) => b.n === 0 && !b.pocketed);
            if (cue) propsRef.current.onAim(Math.atan2(table.y - cue.y, table.x - cue.x));
          }
        }}
        onPointerMove={(event: ReactPointerEvent<HTMLCanvasElement>) => {
          const drag = dragRef.current;
          if (!drag || !event.currentTarget.hasPointerCapture(event.pointerId)) return;
          const point = localPoint(event);
          const layout = layoutFor(point.w, point.h);
          const table = toTable(point.x, point.y, layout);
          if (Math.hypot(point.x - drag.px, point.y - drag.py) > 6 && drag.kind !== "place") {
            drag.moved = true;
          }
          if (drag.kind === "ball" && drag.moved) {
            propsRef.current.onMoveBall(drag.id, table.x, table.y);
          } else if (drag.kind === "aim" && !propsRef.current.placing) {
            const cue = propsRef.current.balls.find((b) => b.n === 0 && !b.pocketed);
            if (cue) propsRef.current.onAim(Math.atan2(table.y - cue.y, table.x - cue.x));
          }
        }}
        onPointerUp={(event: ReactPointerEvent<HTMLCanvasElement>) => {
          const playing = propsRef.current.playback;
          if (playing && !playRef.current.done) {
            playRef.current.done = true;
            propsRef.current.onPlaybackDone(playing.endBalls);
            dragRef.current = null;
            return;
          }
          const drag = dragRef.current;
          dragRef.current = null;
          if (!drag) return;
          const point = localPoint(event);
          const layout = layoutFor(point.w, point.h);
          const table = toTable(point.x, point.y, layout);
          if (drag.kind === "place") {
            propsRef.current.onPlaceCue(table.x, table.y);
            return;
          }
          if (drag.kind === "ball" && !drag.moved) {
            const ball = propsRef.current.balls.find((b) => b.id === drag.id);
            if (ball && ball.n !== 0) propsRef.current.onSelectBall(ball.id);
            return;
          }
          if (drag.kind === "aim" && !drag.moved && drag.pocket) {
            propsRef.current.onSelectPocket(drag.pocket);
          }
        }}
      />
      <p className="hint-pill pointer-events-none absolute top-3 left-1/2 -translate-x-1/2 rounded-full px-3 py-1 text-center text-sm text-muted">
        {placing ? "Tap the cloth to drop the cue ball" : "Drag the cloth to aim. Drag a ball to move it."}
      </p>
    </div>
  );
}

function paintTable(ctx: CanvasRenderingContext2D, layout: Layout) {
  const { ox, oy, rail, feltW, feltH, fx, fy } = layout;
  const outerW = feltW + rail * 2;
  const outerH = feltH + rail * 2;
  roundRect(ctx, ox, oy, outerW, outerH, rail * 0.55);
  const wood = ctx.createLinearGradient(ox, oy, ox + outerW, oy + outerH);
  wood.addColorStop(0, "#8d5a34");
  wood.addColorStop(0.45, "#6a3b1e");
  wood.addColorStop(1, "#3e2415");
  ctx.fillStyle = wood;
  ctx.fill();

  ctx.save();
  roundRect(ctx, fx, fy, feltW, feltH, 6);
  ctx.clip();
  const felt = ctx.createRadialGradient(
    fx + feltW * 0.5,
    fy + feltH * 0.45,
    feltW * 0.1,
    fx + feltW * 0.5,
    fy + feltH * 0.5,
    feltW * 0.72,
  );
  felt.addColorStop(0, "#1c8f58");
  felt.addColorStop(0.7, "#157a4b");
  felt.addColorStop(1, "#0c4a30");
  ctx.fillStyle = felt;
  ctx.fillRect(fx, fy, feltW, feltH);
  ctx.globalAlpha = 0.55;
  ctx.drawImage(feltNoise(), fx, fy, feltW, feltH);
  ctx.globalAlpha = 1;
  ctx.restore();

  ctx.save();
  ctx.strokeStyle = "rgba(243,239,228,0.16)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  const headA = toScreen(0.5, 0, layout);
  const headB = toScreen(0.5, WIDTH, layout);
  ctx.moveTo(headA.x, headA.y);
  ctx.lineTo(headB.x, headB.y);
  ctx.stroke();
  for (const spot of [
    { x: 0.5, y: 0.5 },
    { x: 1.5, y: 0.5 },
  ]) {
    const p = toScreen(spot.x, spot.y, layout);
    ctx.beginPath();
    ctx.arc(p.x, p.y, 2.5, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(243,239,228,0.35)";
    ctx.fill();
  }
  ctx.restore();

  for (const pocket of POCKETS) {
    const p = toScreen(pocket.x, pocket.y, layout);
    const radius = Math.max(13, pocket.lip * layout.scale * 1.55);
    ctx.beginPath();
    ctx.arc(p.x, p.y, radius, 0, Math.PI * 2);
    const hole = ctx.createRadialGradient(p.x, p.y, radius * 0.2, p.x, p.y, radius);
    hole.addColorStop(0, "#1a120e");
    hole.addColorStop(1, "#050403");
    ctx.fillStyle = hole;
    ctx.fill();
    ctx.lineWidth = 3;
    ctx.strokeStyle = "#2a1a10";
    ctx.stroke();
  }

  const out = (layout.rail / layout.scale) * 0.46;
  const diamonds: { x: number; y: number }[] = [];
  for (const t of [0.125, 0.25, 0.375, 0.625, 0.75, 0.875]) {
    diamonds.push({ x: LENGTH * t, y: -out }, { x: LENGTH * t, y: WIDTH + out });
  }
  for (const t of [0.25, 0.5, 0.75]) {
    diamonds.push({ x: -out, y: WIDTH * t }, { x: LENGTH + out, y: WIDTH * t });
  }
  ctx.fillStyle = "rgba(228,177,90,0.72)";
  const d = Math.max(3, layout.rail * 0.16);
  for (const spot of diamonds) {
    const p = toScreen(spot.x, spot.y, layout);
    ctx.beginPath();
    ctx.moveTo(p.x, p.y - d);
    ctx.lineTo(p.x + d * 0.7, p.y);
    ctx.lineTo(p.x, p.y + d);
    ctx.lineTo(p.x - d * 0.7, p.y);
    ctx.closePath();
    ctx.fill();
  }
}

function paintGuides(
  ctx: CanvasRenderingContext2D,
  layout: Layout,
  props: {
    showCall: boolean;
    showTracks: boolean;
    analysis: Analysis;
    calledBallId: string | null;
    calledPocketId: PocketId | null;
    balls: Ball[];
  },
) {
  const { analysis } = props;
  const hideIdeal = analysis.status === "bank" || analysis.status === "hand" || analysis.status === "clear";
  if (props.showCall && analysis.call && props.calledPocketId && props.calledBallId && !hideIdeal) {
    const pocket = POCKETS.find((p) => p.id === props.calledPocketId);
    const ball = props.balls.find((b) => b.id === props.calledBallId);
    if (pocket && ball && !ball.pocketed) {
      const p = toScreen(pocket.x, pocket.y, layout);
      const b = toScreen(ball.x, ball.y, layout);
      const g = toScreen(analysis.call.ghost.x, analysis.call.ghost.y, layout);
      const cue = props.balls.find((item) => item.n === 0 && !item.pocketed);
      ctx.save();
      ctx.strokeStyle = "rgba(228,177,90,0.95)";
      ctx.lineWidth = 1.75;
      ctx.setLineDash([6, 7]);
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(b.x, b.y);
      ctx.lineTo(g.x, g.y);
      if (cue) {
        const c = toScreen(cue.x, cue.y, layout);
        ctx.moveTo(c.x, c.y);
        ctx.lineTo(g.x, g.y);
      }
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(g.x, g.y, BALL_R * layout.scale, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
  }

  if (props.showTracks) {
    const hit = analysis.sim.firstContact?.id;
    for (const track of analysis.sim.tracks) {
      const pts = track.pts.map((p) => toScreen(p.x, p.y, layout));
      if (track.id === "cue") drawDots(ctx, pts, "rgba(243,239,228,0.92)", 2.15);
      else {
        ctx.beginPath();
        pts.forEach((p, i) => (i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y)));
        ctx.strokeStyle = track.id === hit ? GOLD : "rgba(243,239,228,0.38)";
        ctx.lineWidth = track.id === hit ? 2.4 : 1.35;
        ctx.lineJoin = "round";
        ctx.lineCap = "round";
        ctx.stroke();
      }
    }
  }

  if (props.calledPocketId) {
    const pocket = POCKETS.find((p) => p.id === props.calledPocketId);
    if (pocket) {
      const p = toScreen(pocket.x, pocket.y, layout);
      ctx.beginPath();
      ctx.arc(p.x, p.y, Math.max(16, pocket.lip * layout.scale * 1.85), 0, Math.PI * 2);
      ctx.strokeStyle = GOLD;
      ctx.lineWidth = 2;
      ctx.stroke();
    }
  }

  const scratch = analysis.sim.pocketed.find((p) => p.id === "cue");
  if (scratch) {
    const pocket = POCKETS.find((p) => p.id === scratch.pocket);
    if (pocket) {
      const p = toScreen(pocket.x, pocket.y, layout);
      ctx.beginPath();
      ctx.setLineDash([3, 4]);
      ctx.arc(p.x, p.y, Math.max(18, pocket.lip * layout.scale * 2.1), 0, Math.PI * 2);
      ctx.strokeStyle = CREAM;
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.setLineDash([]);
    }
  }
}

function paintCue(
  ctx: CanvasRenderingContext2D,
  layout: Layout,
  balls: Ball[],
  aim: number,
  power: number,
) {
  const cue = balls.find((b) => b.n === 0 && !b.pocketed);
  if (!cue) return;
  const origin = toScreen(cue.x, cue.y, layout);
  const dir = aimOnScreen(aim, layout.portrait);
  const radius = BALL_R * layout.scale;
  const backX = -dir.x;
  const backY = -dir.y;
  const gap = radius * (0.85 + power * 1.7);
  const length = Math.min(layout.feltW, layout.feltH) * (layout.portrait ? 0.42 : 0.38);
  const sx = origin.x + backX * (radius + gap);
  const sy = origin.y + backY * (radius + gap);
  const ex = sx + backX * length;
  const ey = sy + backY * length;
  const grad = ctx.createLinearGradient(sx, sy, ex, ey);
  grad.addColorStop(0, "#f7f4ee");
  grad.addColorStop(0.05, "#d9c7a2");
  grad.addColorStop(0.14, "#e4b15a");
  grad.addColorStop(1, "#5c371c");
  ctx.strokeStyle = grad;
  ctx.lineWidth = Math.max(4, radius * 0.32);
  ctx.lineCap = "butt";
  ctx.beginPath();
  ctx.moveTo(sx, sy);
  ctx.lineTo(ex, ey);
  ctx.stroke();
  ctx.fillStyle = "#24180f";
  ctx.beginPath();
  ctx.arc(sx, sy, Math.max(2.4, radius * 0.14), 0, Math.PI * 2);
  ctx.fill();
}
