import { useEffect, useMemo, useRef, useState, type PointerEvent as ReactPointerEvent } from "react";
import { RotateCcw, RotateCw, Undo2 } from "lucide-react";
import { PoolCanvas } from "@/components/pool-canvas";
import {
  PRESETS,
  analyze,
  ballName,
  bestPocket,
  clampBall,
  pocketById,
  presetById,
  type Ball,
  type PocketId,
  type SimResult,
  type Spin,
} from "@/lib/pool/model";

type Snap = {
  balls: Ball[];
  aim: number;
  calledBallId: string | null;
  calledPocketId: PocketId | null;
};

const opening = PRESETS[0];

function cloneBalls(balls: Ball[]): Ball[] {
  return balls.map((ball) => ({ ...ball }));
}

function spinLabel(spin: Spin): string {
  const follow = spin.y > 0.08 ? "Follow" : spin.y < -0.08 ? "Draw" : null;
  const side = spin.x > 0.08 ? "Right english" : spin.x < -0.08 ? "Left english" : null;
  if (!follow && !side) return "Center ball. Stun sends the cue square.";
  return [follow, side].filter(Boolean).join(" · ");
}

export function OverlayApp() {
  const [balls, setBalls] = useState<Ball[]>(() => cloneBalls(opening.balls));
  const [aim, setAim] = useState(opening.aim);
  const [power, setPower] = useState(opening.power);
  const [spin, setSpin] = useState<Spin>(opening.spin);
  const [calledBallId, setCalledBallId] = useState<string | null>(opening.calledBallId);
  const [calledPocketId, setCalledPocketId] = useState<PocketId | null>(opening.calledPocketId);
  const [showCall, setShowCall] = useState(true);
  const [showTracks, setShowTracks] = useState(true);
  const [presetId, setPresetId] = useState(opening.id);
  const [hand, setHand] = useState(false);
  const [history, setHistory] = useState<Snap[]>([]);
  const [playback, setPlayback] = useState<SimResult | null>(null);

  const analysis = useMemo(
    () => analyze(balls, aim, power, spin, calledBallId, calledPocketId),
    [balls, aim, power, spin, calledBallId, calledPocketId],
  );

  const cuePocketed = balls.some((ball) => ball.n === 0 && ball.pocketed);
  const placing = hand || cuePocketed;
  const rolling = playback !== null;
  const preset = presetById(presetId);
  const called = balls.find((ball) => ball.id === calledBallId && !ball.pocketed);
  const up = balls.filter((ball) => ball.n !== 0 && !ball.pocketed).length;

  const title = rolling ? "Rolling" : cuePocketed ? "Cue in hand" : analysis.title;
  const detail = rolling
    ? "Tap the cloth to skip ahead."
    : placing && !cuePocketed
      ? "Tap the cloth to drop the cue ball."
      : analysis.detail;

  const cutText = rolling
    ? "—"
    : analysis.status === "bank"
      ? "1"
      : analysis.status === "combo"
        ? "2"
        : analysis.cutDeg == null
          ? "—"
          : String(Math.round(analysis.cutDeg));
  const cutCaption =
    analysis.status === "bank" ? "rail" : analysis.status === "combo" ? "ball" : "cut";

  function load(id: string) {
    const next = presetById(id);
    setBalls(cloneBalls(next.balls));
    setAim(next.aim);
    setPower(next.power);
    setSpin(next.spin);
    setCalledBallId(next.calledBallId);
    setCalledPocketId(next.calledPocketId);
    setPresetId(id);
    setHand(false);
    setPlayback(null);
  }

  function undo() {
    const prev = history[history.length - 1];
    if (!prev || rolling) return;
    setBalls(cloneBalls(prev.balls));
    setAim(prev.aim);
    setCalledBallId(prev.calledBallId);
    setCalledPocketId(prev.calledPocketId);
    setHistory((stack) => stack.slice(0, -1));
    setHand(false);
    setPlayback(null);
  }

  function stroke() {
    if (rolling || placing || power < 0.04) return;
    if (!balls.some((ball) => ball.n === 0 && !ball.pocketed)) return;
    setHistory((stack) =>
      [...stack, { balls: cloneBalls(balls), aim, calledBallId, calledPocketId }].slice(-20),
    );
    setPlayback(analysis.sim);
  }

  function finish(end: Ball[]) {
    setBalls(end);
    setPlayback(null);
    if (end.some((ball) => ball.n === 0 && ball.pocketed)) setHand(true);
    if (calledBallId && end.find((ball) => ball.id === calledBallId)?.pocketed) {
      const next = end.find((ball) => ball.n !== 0 && !ball.pocketed);
      setCalledBallId(next?.id ?? null);
      setCalledPocketId(next ? bestPocket(end, next) : null);
    }
  }

  const actions = useRef({ stroke, undo, rolling: false });
  actions.current = { stroke, undo, rolling };

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      const target = event.target;
      if (
        target instanceof HTMLInputElement ||
        target instanceof HTMLTextAreaElement ||
        target instanceof HTMLButtonElement
      ) {
        return;
      }
      if (actions.current.rolling) return;
      if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
        event.preventDefault();
        const step = event.shiftKey ? 0.004 : 0.014;
        setAim((value) => value + (event.key === "ArrowLeft" ? -step : step));
      } else if (event.key === " ") {
        event.preventDefault();
        actions.current.stroke();
      } else if ((event.key === "z" || event.key === "Z") && (event.metaKey || event.ctrlKey)) {
        event.preventDefault();
        actions.current.undo();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const callLabel = called
    ? calledPocketId
      ? `${ballName(called.n)} · ${pocketById(calledPocketId).name}`
      : ballName(called.n)
    : "Tap a ball, then a pocket";

  return (
    <main className="app-shell flex h-dvh flex-col bg-bg text-cream">
      <header className="flex shrink-0 items-center justify-between gap-3 border-b border-line px-4 py-3">
        <div>
          <p className="font-display text-sm tracking-widest text-gold">8-BALL AIM OVERLAY</p>
          <h1 className="font-display text-4xl leading-none text-cream">Cueline</h1>
        </div>
        <div className="flex items-center gap-2">
          <p className="hidden text-sm text-muted sm:block">{up} up</p>
          <button
            type="button"
            className="flex size-11 items-center justify-center rounded-full border border-line bg-surface text-cream disabled:opacity-40"
            aria-label="Undo last stroke"
            disabled={history.length === 0 || rolling}
            onClick={undo}
          >
            <Undo2 className="size-5" aria-hidden="true" />
          </button>
          <button
            type="button"
            className="flex size-11 items-center justify-center rounded-full border border-line bg-surface text-cream"
            aria-label="Reset this leave"
            onClick={() => load(presetId)}
          >
            <RotateCcw className="size-5" aria-hidden="true" />
          </button>
        </div>
      </header>

      <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
        <div className="table-stage relative min-h-0 flex-1">
          <PoolCanvas
            balls={balls}
            aim={aim}
            power={power}
            calledBallId={calledBallId}
            calledPocketId={calledPocketId}
            showCall={showCall}
            showTracks={showTracks}
            analysis={analysis}
            playback={playback}
            placing={placing}
            onPlaybackDone={finish}
            onAim={setAim}
            onMoveBall={(id, x, y) => {
              setBalls((prev) =>
                prev.map((ball) =>
                  ball.id === id ? { ...ball, ...clampBall({ x, y }, prev, id), pocketed: false } : ball,
                ),
              );
            }}
            onSelectBall={(id) => {
              const ball = balls.find((item) => item.id === id);
              if (!ball || ball.n === 0) return;
              setCalledBallId(id);
              setCalledPocketId(bestPocket(balls, ball));
            }}
            onSelectPocket={setCalledPocketId}
            onPlaceCue={(x, y) => {
              setBalls((prev) =>
                prev.map((ball) =>
                  ball.n === 0
                    ? { ...ball, ...clampBall({ x, y }, prev, ball.id), pocketed: false }
                    : ball,
                ),
              );
              setHand(false);
            }}
          />
        </div>

        <aside className="panel-scroll flex shrink-0 flex-col gap-3 overflow-y-auto border-t border-line px-4 py-3 lg:border-t-0 lg:border-l">
          <div className="flex items-end justify-between gap-3">
            <div className="min-w-0">
              <p className="font-display text-3xl leading-none text-gold" aria-live="polite">
                {title}
              </p>
              <p className="mt-1 text-sm text-pretty text-muted">{detail}</p>
            </div>
            <div className="text-right">
              <p className="font-display text-4xl leading-none tabular-nums text-cream">{cutText}</p>
              <p className="font-display text-sm tracking-widest text-muted">{cutCaption}</p>
            </div>
          </div>

          <p className="text-sm text-cream">{callLabel}</p>

          <label className="block">
            <span className="mb-1 flex items-center justify-between text-sm">
              <span className="text-muted">Power</span>
              <span className="tabular-nums text-cream">{Math.round(power * 100)}</span>
            </span>
            <input
              className="power-range"
              type="range"
              min={0.08}
              max={1}
              step={0.01}
              value={power}
              aria-valuemin={8}
              aria-valuemax={100}
              aria-valuenow={Math.round(power * 100)}
              aria-label="Shot power"
              disabled={rolling}
              onChange={(event) => setPower(Number(event.target.value))}
            />
          </label>

          <div className="flex items-center gap-3">
            <SpinPad spin={spin} disabled={rolling} onChange={setSpin} />
            <div className="flex min-w-0 flex-1 flex-col gap-2">
              <p className="text-sm text-pretty text-muted">{spinLabel(spin)}</p>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  className="flex h-11 items-center justify-center rounded-lg border border-line bg-surface text-cream"
                  aria-label="Nudge aim counterclockwise"
                  disabled={rolling}
                  onClick={() => setAim((value) => value - 0.012)}
                >
                  <RotateCcw className="size-4" aria-hidden="true" />
                </button>
                <button
                  type="button"
                  className="flex h-11 items-center justify-center rounded-lg border border-line bg-surface text-sm text-cream"
                  disabled={rolling}
                  onClick={() => setSpin({ x: 0, y: 0 })}
                >
                  Stun
                </button>
                <button
                  type="button"
                  className="flex h-11 items-center justify-center rounded-lg border border-line bg-surface text-cream"
                  aria-label="Nudge aim clockwise"
                  disabled={rolling}
                  onClick={() => setAim((value) => value + 0.012)}
                >
                  <RotateCw className="size-4" aria-hidden="true" />
                </button>
              </div>
              <button
                type="button"
                className="stroke-btn h-12 rounded-lg font-display text-2xl tracking-wide"
                disabled={rolling || placing}
                onClick={stroke}
              >
                {rolling ? "Rolling" : "Stroke"}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <Toggle pressed={showCall} onClick={() => setShowCall((value) => !value)}>
              Call line
            </Toggle>
            <Toggle pressed={showTracks} onClick={() => setShowTracks((value) => !value)}>
              Tracks
            </Toggle>
            <button
              type="button"
              className="h-11 rounded-lg border border-line bg-surface text-sm text-cream disabled:opacity-40"
              disabled={rolling}
              onClick={() => setHand(true)}
            >
              Place cue
            </button>
          </div>

          <div className="flex gap-2 overflow-x-auto pb-1">
            {PRESETS.map((item) => {
              const active = item.id === presetId;
              return (
                <button
                  key={item.id}
                  type="button"
                  className={
                    active
                      ? "h-11 shrink-0 rounded-full bg-gold px-4 text-sm font-medium text-gold-ink"
                      : "h-11 shrink-0 rounded-full border border-line bg-surface px-4 text-sm text-cream"
                  }
                  aria-pressed={active}
                  onClick={() => load(item.id)}
                >
                  {item.name}
                </button>
              );
            })}
          </div>
          <p className="text-sm text-pretty text-muted">{preset.hint}</p>
        </aside>
      </div>
    </main>
  );
}

function Toggle({
  pressed,
  onClick,
  children,
}: {
  pressed: boolean;
  onClick: () => void;
  children: string;
}) {
  return (
    <button
      type="button"
      aria-pressed={pressed}
      onClick={onClick}
      className={
        pressed
          ? "h-11 rounded-lg border border-gold bg-surface-2 text-sm text-cream"
          : "h-11 rounded-lg border border-line bg-surface text-sm text-muted"
      }
    >
      {children}
    </button>
  );
}

function SpinPad({
  spin,
  disabled,
  onChange,
}: {
  spin: Spin;
  disabled: boolean;
  onChange: (spin: Spin) => void;
}) {
  function fromEvent(event: ReactPointerEvent<HTMLDivElement>) {
    const rect = event.currentTarget.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    const y = ((event.clientY - rect.top) / rect.height) * 2 - 1;
    onChange({
      x: Math.min(1, Math.max(-1, x)),
      y: Math.min(1, Math.max(-1, -y)),
    });
  }

  return (
    <div
      className="spin-pad"
      role="group"
      aria-label="Cue tip. Up is follow, down is draw, sides are english."
      onPointerDown={(event) => {
        if (disabled) return;
        event.currentTarget.setPointerCapture(event.pointerId);
        fromEvent(event);
      }}
      onPointerMove={(event) => {
        if (!event.currentTarget.hasPointerCapture(event.pointerId)) return;
        fromEvent(event);
      }}
      onDoubleClick={() => onChange({ x: 0, y: 0 })}
    >
      <span
        className="spin-dot"
        style={{ left: `${((spin.x + 1) / 2) * 100}%`, top: `${((-spin.y + 1) / 2) * 100}%` }}
      />
    </div>
  );
}
