import { createFileRoute } from "@tanstack/react-router";
import { OverlayApp } from "@/components/overlay-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <OverlayApp />;
}
